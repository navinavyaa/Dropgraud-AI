/**
 * DropGuard AI — Excel-backed API server.
 * EVERY value shown in the app lives in (or is computed live from) Excel files in /data:
 *   students.xlsx      credentials + academics + streak/XP + subject marks + attendance history
 *   teachers.xlsx      teacher credentials (Teacher ID based)
 *   admins.xlsx        admin credentials
 *   events.xlsx        calendar / study-schedule events
 *   internships.xlsx   internship listings
 *   jobs.xlsx          job listings
 *   certificates.xlsx  per-student certificates (linked by Email)
 *   meta.xlsx          landing stats, testimonials, ML model versions
 * Files are seeded automatically on first run and appended to on every registration.
 */
import express from "express";
import * as XLSX from "xlsx";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, "..");
const DATA_DIR = path.join(ROOT, "data");
const F = (n) => path.join(DATA_DIR, n);
const FILES = {
  students: F("students.xlsx"),
  teachers: F("teachers.xlsx"),
  admins: F("admins.xlsx"),
  events: F("events.xlsx"),
  internships: F("internships.xlsx"),
  jobs: F("jobs.xlsx"),
  certificates: F("certificates.xlsx"),
  meta: F("meta.xlsx"),
  messages: F("messages.xlsx"),
  resumes: F("resumes.xlsx"),
  assignments: F("assignments.xlsx"),
  submissions: F("submissions.xlsx"),
};
const UPLOADS = path.join(DATA_DIR, "uploads");

export const SUBJECTS = ["Maths", "DSA", "DBMS", "OS", "Networks", "AIML"];

/* ---------- Centralized dropout risk (single source of truth) ---------- */
export function computeRisk(attendance, cgpa) {
  const a = Number(attendance) || 0;
  const c = Number(cgpa) || 0;
  const score = Math.max(0, Math.min(100, Math.round(100 - (0.55 * a + 4.5 * c))));
  const level = score < 20 ? "Low" : score < 40 ? "Medium" : "High";
  return { score, level };
}

/* ---------- Excel helpers (buffer based — works with the xlsx ESM build) ---------- */
function readBook(file) {
  if (!fs.existsSync(file)) return null;
  return XLSX.read(fs.readFileSync(file), { type: "buffer" });
}
function readRows(file, sheet) {
  const wb = readBook(file);
  if (!wb) return [];
  const name = sheet && wb.SheetNames.includes(sheet) ? sheet : wb.SheetNames[0];
  return XLSX.utils.sheet_to_json(wb.Sheets[name], { defval: "" });
}
function writeBook(file, sheets) {
  const wb = XLSX.utils.book_new();
  for (const [name, rows] of Object.entries(sheets)) {
    XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(rows), name);
  }
  fs.writeFileSync(file, XLSX.write(wb, { type: "buffer", bookType: "xlsx" }));
}
function writeRows(file, rows, sheetName) {
  writeBook(file, { [sheetName]: rows });
}
function appendRow(file, row, sheetName) {
  const rows = readRows(file);
  rows.push(row);
  writeRows(file, rows, sheetName);
}
function updateSheet(file, sheet, rows) {
  const wb = readBook(file);
  const sheets = {};
  if (wb) for (const n of wb.SheetNames) sheets[n] = XLSX.utils.sheet_to_json(wb.Sheets[n], { defval: "" });
  sheets[sheet] = rows;
  writeBook(file, sheets);
}

/* ---------- Seeding ---------- */
const FIRST = ["Aarav", "Priya", "Rohan", "Sneha", "Vikram", "Ananya", "Karthik", "Divya", "Arjun", "Meera",
  "Aditya", "Ishita", "Rahul", "Kavya", "Siddharth", "Pooja", "Nikhil", "Shreya", "Manish", "Lakshmi",
  "Varun", "Nandini", "Deepak", "Ritika", "Suresh"];
const LAST = ["Sharma", "Patel", "Kumar", "Reddy", "Singh", "Iyer", "Nair", "Menon", "Das", "Krishnan",
  "Verma", "Gupta", "Rao", "Pillai", "Joshi", "Mehta", "Bose", "Chandran", "Mishra", "Naidu"];
const DEPTS = ["CSE", "ECE", "IT", "MECH", "CIVIL", "EEE"];
const rand = (min, max) => Math.round((min + Math.random() * (max - min)) * 10) / 10;
const randInt = (min, max) => Math.floor(min + Math.random() * (max - min + 1));
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));

function seedStudents() {
  const rows = [];
  for (let i = 0; i < 50; i++) {
    const name = `${FIRST[i % FIRST.length]} ${LAST[(i * 7 + 3) % LAST.length]}`;
    const attendance = randInt(45, 98);
    const cgpa = rand(4.5, 9.8);
    const { score, level } = computeRisk(attendance, cgpa);
    const base = clamp(Math.round(cgpa * 10 + randInt(-8, 8)), 35, 99);
    const marks = Object.fromEntries(SUBJECTS.map((s) => [s, clamp(base + randInt(-12, 12), 30, 100)]));
    const att = Object.fromEntries(
      Array.from({ length: 6 }, (_, m) => [`Att${m + 1}`, clamp(attendance + randInt(-8, 8), 40, 100)])
    );
    rows.push({
      Name: name,
      Email: `${name.toLowerCase().replace(/\s+/g, ".")}${i + 1}@college.edu`,
      Password: "student123",
      Department: DEPTS[randInt(0, DEPTS.length - 1)],
      Year: randInt(1, 4),
      Attendance: attendance,
      CGPA: cgpa,
      QuizAverage: clamp(base + randInt(-10, 10), 30, 100),
      SemMarks: clamp(base + randInt(-8, 8), 30, 100),
      StudyStreak: randInt(0, 25),
      XP: randInt(400, 5200),
      ...marks,
      ...att,
      RiskScore: score,
      RiskLevel: level,
      RegisteredAt: new Date().toISOString(),
    });
  }
  writeRows(FILES.students, rows, "Students");
  console.log("Seeded 50 students -> data/students.xlsx");
}

function seedTeachers() {
  const rows = [];
  for (let i = 0; i < 20; i++) {
    rows.push({
      TeacherID: `T${String(i + 1).padStart(3, "0")}`,
      Name: `Prof. ${FIRST[(i * 3 + 1) % FIRST.length]} ${LAST[(i * 5 + 2) % LAST.length]}`,
      Password: "teach123",
      Department: DEPTS[i % DEPTS.length],
      RegisteredAt: new Date().toISOString(),
    });
  }
  writeRows(FILES.teachers, rows, "Teachers");
  console.log("Seeded 20 teachers -> data/teachers.xlsx");
}

function seedAdmins() {
  writeRows(FILES.admins, [
    { Name: "System Admin", Email: "admin@dropguard.ai", Password: "admin123", RegisteredAt: new Date().toISOString() },
  ], "Admins");
}

function seedEvents() {
  const today = new Date();
  const d = (days) => new Date(today.getTime() + days * 86400000).toISOString().slice(0, 10);
  writeRows(FILES.events, [
    { Title: "AI/ML Assignment 2 Due", Date: d(1), Type: "Deadline", Color: "#EF4444" },
    { Title: "DBMS Quiz 3", Date: d(2), Type: "Exam", Color: "#7C3AED" },
    { Title: "Mentor Meeting", Date: d(4), Type: "Meeting", Color: "#F59E0B" },
    { Title: "TechNova Placement Drive", Date: d(7), Type: "Placement", Color: "#06B6D4" },
    { Title: "Mock Interview — HR Round", Date: d(9), Type: "Interview", Color: "#22C55E" },
    { Title: "Networks Lab Assessment", Date: d(12), Type: "Exam", Color: "#7C3AED" },
    { Title: "Mid-Semester Exams Begin", Date: d(19), Type: "Exam", Color: "#7C3AED" },
  ], "Events");
}

function seedInternships() {
  writeRows(FILES.internships, [
    { Company: "TechNova Solutions", Role: "Python Developer Intern", Location: "Bengaluru", Stipend: "₹20,000/mo", Duration: "3 months", MinCGPA: 7.0, Skills: "Python,SQL", Deadline: "2026-07-25" },
    { Company: "DataMinds Analytics", Role: "Data Analyst Intern", Location: "Remote", Stipend: "₹15,000/mo", Duration: "6 months", MinCGPA: 6.5, Skills: "Excel,Python,PowerBI", Deadline: "2026-07-30" },
    { Company: "CloudSprint", Role: "Frontend Intern (React)", Location: "Hyderabad", Stipend: "₹18,000/mo", Duration: "4 months", MinCGPA: 7.0, Skills: "React,TypeScript", Deadline: "2026-08-05" },
    { Company: "NeuralWorks AI", Role: "ML Research Intern", Location: "Chennai", Stipend: "₹25,000/mo", Duration: "6 months", MinCGPA: 8.0, Skills: "Python,PyTorch,Statistics", Deadline: "2026-08-10" },
    { Company: "InfraGrid", Role: "Embedded Systems Intern", Location: "Pune", Stipend: "₹16,000/mo", Duration: "3 months", MinCGPA: 6.0, Skills: "C,Microcontrollers", Deadline: "2026-08-12" },
  ], "Internships");
}

function seedJobs() {
  writeRows(FILES.jobs, [
    { Company: "Infowave Systems", Role: "Graduate Software Engineer", Location: "Bengaluru", Salary: "₹6.5 LPA", Skills: "Python,SQL,DSA" },
    { Company: "Quantica Labs", Role: "Junior Data Scientist", Location: "Pune", Salary: "₹8 LPA", Skills: "Python,ML,Statistics" },
    { Company: "BrightApps", Role: "Frontend Developer", Location: "Remote", Salary: "₹5.5 LPA", Skills: "React,JavaScript,CSS" },
    { Company: "CoreStack", Role: "Backend Developer", Location: "Chennai", Salary: "₹7 LPA", Skills: "Java,Spring,SQL" },
    { Company: "GridWorks", Role: "Site Engineer Trainee", Location: "Coimbatore", Salary: "₹4.8 LPA", Skills: "AutoCAD,Surveying" },
  ], "Jobs");
}

function seedCertificates(studentRows) {
  const pool = [
    { Title: "Python for Everybody", Issuer: "Coursera", Category: "Course" },
    { Title: "SQL Fundamentals", Issuer: "HackerRank", Category: "Badge" },
    { Title: "Hackathon Winner — CodeStorm", Issuer: "IEEE", Category: "Achievement" },
    { Title: "Web Development Internship", Issuer: "CloudSprint", Category: "Internship" },
    { Title: "Machine Learning Specialization", Issuer: "Coursera", Category: "Course" },
    { Title: "Cloud Foundations", Issuer: "AWS Academy", Category: "Badge" },
  ];
  const rows = [];
  studentRows.forEach((s, i) => {
    const n = i % 3; // 0, 1 or 2 certificates each
    for (let k = 0; k < n; k++) {
      const c = pool[(i + k * 2) % pool.length];
      rows.push({ Email: s.Email, ...c, Date: `2026-0${randInt(1, 6)}-1${randInt(0, 9)}` });
    }
  });
  writeRows(FILES.certificates, rows, "Certificates");
}

function seedMeta() {
  writeBook(FILES.meta, {
    Stats: [
      { Key: "Institutions", Value: 320 },
      { Key: "PredictionsMade", Value: 1200000 },
    ],
    Models: [
      { Version: "v2.1", Algorithm: "Logistic Regression", Accuracy: 86.4, F1: 0.81, Trained: "2026-02-25", Status: "Archived" },
      { Version: "v2.2", Algorithm: "Random Forest", Accuracy: 91.1, F1: 0.87, Trained: "2026-04-18", Status: "Archived" },
      { Version: "v2.3", Algorithm: "XGBoost", Accuracy: 92.8, F1: 0.89, Trained: "2026-06-02", Status: "Archived" },
      { Version: "v2.4", Algorithm: "XGBoost", Accuracy: 94.2, F1: 0.91, Trained: "2026-07-14", Status: "Production" },
    ],
    Testimonials: [
      { Name: "Dr. Kavitha Rao", Role: "HoD, Computer Science", Quote: "DropGuard AI flagged 14 at-risk students in the first month. Eleven of them are back on track after targeted interventions." },
      { Name: "Aarav Sharma", Role: "Third-year student", Quote: "The AI study planner and resume builder changed how I prepare. My ATS score went from 58% to 86%." },
      { Name: "Suresh Menon", Role: "Principal", Quote: "Our dropout rate fell 23% in two semesters. The institution-wide analytics are worth it alone." },
    ],
  });
}

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(FILES.students)) seedStudents();
if (!fs.existsSync(FILES.teachers)) seedTeachers();
if (!fs.existsSync(FILES.admins)) seedAdmins();
if (!fs.existsSync(FILES.events)) seedEvents();
if (!fs.existsSync(FILES.internships)) seedInternships();
if (!fs.existsSync(FILES.jobs)) seedJobs();
if (!fs.existsSync(FILES.certificates)) seedCertificates(readRows(FILES.students));
if (!fs.existsSync(FILES.meta)) seedMeta();
if (!fs.existsSync(FILES.messages))
  writeRows(
    FILES.messages,
    [{ Email: "example@college.edu", From: "System", Message: "Example row — teacher messages to students are appended here.", SentAt: new Date().toISOString(), Read: "Yes" }],
    "Messages"
  );
if (!fs.existsSync(FILES.resumes))
  writeRows(
    FILES.resumes,
    [{ Email: "example@college.edu", Data: "{}", UpdatedAt: new Date().toISOString() }],
    "Resumes"
  );
if (!fs.existsSync(UPLOADS)) fs.mkdirSync(UPLOADS, { recursive: true });
if (!fs.existsSync(FILES.assignments))
  writeRows(
    FILES.assignments,
    [{ ID: "", Title: "", Description: "", Subject: "", DueDate: "", Attachment: "", CreatedBy: "", CreatedByID: "", CreatedAt: "" }].slice(0, 0),
    "Assignments"
  );
if (!fs.existsSync(FILES.submissions))
  writeRows(
    FILES.submissions,
    [{ AssignmentID: "EXAMPLE", Email: "example@college.edu", FileName: "", StoredFile: "", SubmittedAt: "", Status: "Not Started", Marks: "", Feedback: "" }],
    "Submissions"
  );

/* ---------- Serialization ---------- */
const initials = (name) =>
  String(name).trim().split(/\s+/).map((n) => n[0]).slice(0, 2).join("").toUpperCase() || "?";
const num = (v) => (v === "" || v === null || v === undefined ? null : Number(v));

function studentToUser(row) {
  const { score, level } = computeRisk(row.Attendance, row.CGPA);
  return {
    role: "student",
    name: row.Name,
    email: row.Email,
    avatar: initials(row.Name),
    department: row.Department,
    year: Number(row.Year),
    attendance: Number(row.Attendance),
    cgpa: Number(row.CGPA),
    quizAverage: num(row.QuizAverage),
    semMarks: num(row.SemMarks),
    studyStreak: Number(row.StudyStreak) || 0,
    xp: Number(row.XP) || 0,
    marks: Object.fromEntries(SUBJECTS.map((s) => [s, num(row[s])])),
    attTrend: Array.from({ length: 6 }, (_, i) => num(row[`Att${i + 1}`])),
    riskScore: score,
    riskLevel: level,
  };
}
const teacherToUser = (row) => ({
  role: "teacher", name: row.Name, teacherId: row.TeacherID, avatar: initials(row.Name), department: row.Department || "",
});
const adminToUser = (row) => ({ role: "admin", name: row.Name, email: row.Email, avatar: initials(row.Name) });

const allStudents = () => readRows(FILES.students).map(studentToUser);
const monthLabels = () => {
  const names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const now = new Date().getMonth();
  return Array.from({ length: 6 }, (_, i) => names[(now - 5 + i + 12) % 12]);
};
const avg = (arr) => {
  const v = arr.filter((x) => typeof x === "number" && !Number.isNaN(x));
  return v.length ? Math.round((v.reduce((a, b) => a + b, 0) / v.length) * 10) / 10 : null;
};

/* ---------- Derived, per-student insights (computed from Excel data) ---------- */
function suggestionsFor(s, events) {
  const out = [];
  if (s.attendance < 75)
    out.push({ tag: "Attendance", text: `Your attendance is ${s.attendance}% — below the 75% requirement. Attend upcoming classes consistently to recover.` });
  else out.push({ tag: "Attendance", text: `Attendance is healthy at ${s.attendance}%. Keep it above 85% to protect your low risk score.` });
  const known = SUBJECTS.filter((x) => typeof s.marks[x] === "number");
  if (known.length) {
    const weakest = known.reduce((a, b) => (s.marks[a] <= s.marks[b] ? a : b));
    out.push({ tag: "Performance", text: `${weakest} is your weakest subject (${s.marks[weakest]}%). A focused revision plan is recommended.` });
  }
  if (s.riskLevel === "High")
    out.push({ tag: "Risk", text: `Your dropout risk is High (${s.riskScore}/100). Meet your mentor this week and follow the recovery plan.` });
  else if (s.riskLevel === "Medium")
    out.push({ tag: "Risk", text: `Your risk is Medium (${s.riskScore}/100). Improving attendance and CGPA will move you to the safe zone.` });
  else out.push({ tag: "Risk", text: `Risk score ${s.riskScore}/100 — you're in the safe zone. Great consistency!` });
  const next = events[0];
  if (next) out.push({ tag: "Schedule", text: `Next up: ${next.title} on ${next.date}. Plan a preparation session today.` });
  return out;
}

const unreadMessagesFor = (email) =>
  readRows(FILES.messages).filter(
    (m) => String(m.Email).toLowerCase() === String(email).toLowerCase() && String(m.Read) !== "Yes"
  );

function notificationsFor(role, s, events, teacherId = "") {
  const out = [];
  const soon = events.filter((e) => e.daysAway >= 0 && e.daysAway <= 3);
  const today = new Date().toISOString().slice(0, 10);
  if (role === "student" && s) {
    unreadMessagesFor(s.email).forEach((m) =>
      out.push({ type: "danger", title: `Message from ${m.From}`, body: m.Message })
    );
    // Assignment notifications — new/pending assignments and released grades
    const subs = readRows(FILES.submissions).filter((r) => String(r.Email).toLowerCase() === s.email.toLowerCase());
    readRows(FILES.assignments).forEach((a) => {
      const sub = subs.find((x) => String(x.AssignmentID) === String(a.ID));
      if (!sub?.SubmittedAt && a.DueDate >= today) {
        out.push({ type: "warning", title: `New Assignment: ${a.Title}`, body: `${a.Subject ? a.Subject + " · " : ""}Due ${new Date(a.DueDate).toLocaleDateString("en-US", { month: "short", day: "2-digit" })} — submit a PDF or Word document from the Assignments page.` });
      } else if (sub && (sub.Status === "Graded" || sub.Status === "Approved" || sub.Status === "Rejected")) {
        out.push({ type: sub.Status === "Rejected" ? "danger" : "success", title: `Assignment ${sub.Status}: ${a.Title}`, body: sub.Status === "Graded" && sub.Marks !== "" ? `You scored ${sub.Marks} marks.${sub.Feedback ? ` Feedback: ${sub.Feedback}` : ""}` : sub.Feedback || `Your submission was ${String(sub.Status).toLowerCase()}.` });
      }
    });
    if (s.attendance < 75)
      out.push({ type: "warning", title: "Low Attendance Alert", body: `Your attendance is ${s.attendance}% — below the 75% requirement.` });
    if (s.riskLevel === "High")
      out.push({ type: "danger", title: "High Risk Warning", body: `Your dropout risk score is ${s.riskScore}/100. An intervention plan is recommended.` });
    soon.forEach((e) => out.push({ type: e.type === "Deadline" ? "danger" : "info", title: `${e.type}: ${e.title}`, body: `Scheduled for ${e.date} (${e.daysAway === 0 ? "today" : `in ${e.daysAway} day${e.daysAway > 1 ? "s" : ""}`}).` }));
    if (s.studyStreak >= 7)
      out.push({ type: "success", title: `${s.studyStreak}-Day Study Streak`, body: "Keep the momentum — your streak is among the best in class." });
  } else {
    const students = allStudents();
    const high = students.filter((x) => x.riskLevel === "High");
    if (high.length) out.push({ type: "danger", title: `${high.length} High-Risk Students`, body: `${high.slice(0, 3).map((x) => x.name).join(", ")}${high.length > 3 ? "…" : ""} need intervention.` });
    const lowAtt = students.filter((x) => x.attendance < 75).length;
    if (lowAtt) out.push({ type: "warning", title: "Attendance Watch", body: `${lowAtt} students are below 75% attendance.` });
    // Only count submissions for THIS teacher's own assignments
    const myAssignmentIds = new Set(
      readRows(FILES.assignments)
        .filter((a) => !teacherId || String(a.CreatedByID).toUpperCase() === teacherId.toUpperCase())
        .map((a) => String(a.ID))
    );
    const awaiting = readRows(FILES.submissions).filter(
      (r) => r.SubmittedAt && r.Status === "Submitted" && myAssignmentIds.has(String(r.AssignmentID))
    ).length;
    if (awaiting) out.push({ type: "info", title: "Submissions Awaiting Review", body: `${awaiting} assignment submission${awaiting > 1 ? "s" : ""} waiting for your review.` });
    soon.forEach((e) => out.push({ type: "info", title: `${e.type}: ${e.title}`, body: `Scheduled for ${e.date}.` }));
  }
  return out;
}

function eventList() {
  const today = new Date(new Date().toISOString().slice(0, 10));
  return readRows(FILES.events)
    .map((e) => {
      const dt = new Date(e.Date);
      return {
        title: e.Title, type: e.Type, color: e.Color, iso: e.Date,
        date: dt.toLocaleDateString("en-US", { month: "short", day: "2-digit" }),
        daysAway: Math.round((dt - today) / 86400000),
      };
    })
    .filter((e) => e.daysAway >= -1)
    .sort((a, b) => a.daysAway - b.daysAway);
}

/* ---------- API ---------- */
const app = express();
app.use(express.json({ limit: "25mb" }));
const bad = (res, error, code = 400) => res.status(code).json({ ok: false, error });

/* Uploaded files (assignment attachments + student submissions) live in data/uploads */
app.use("/api/files", express.static(UPLOADS));

function saveUpload(name, dataBase64) {
  const safe = `${Date.now()}_${String(name).replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  fs.writeFileSync(path.join(UPLOADS, safe), Buffer.from(dataBase64, "base64"));
  return safe;
}
const ALLOWED_EXT = /\.(pdf|doc|docx)$/i;

app.post("/api/auth/signup", (req, res) => {
  const { role } = req.body || {};
  if (role === "student") {
    const { name, email, password, department, year, attendance, cgpa } = req.body;
    if (!name?.trim() || !email?.trim() || !password || !department || !year) return bad(res, "Please fill in all fields.");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) return bad(res, "Please enter a valid college email.");
    if (password.length < 6) return bad(res, "Password must be at least 6 characters.");
    const att = Number(attendance), cg = Number(cgpa);
    if (Number.isNaN(att) || att < 0 || att > 100) return bad(res, "Attendance must be between 0 and 100.");
    if (Number.isNaN(cg) || cg < 0 || cg > 10) return bad(res, "CGPA must be between 0 and 10.");
    const rows = readRows(FILES.students);
    const cleanEmail = email.trim().toLowerCase();
    if (rows.some((r) => String(r.Email).toLowerCase() === cleanEmail))
      return bad(res, "This college email is already registered. Please login instead.");
    const { score, level } = computeRisk(att, cg);
    const row = {
      Name: name.trim(), Email: cleanEmail, Password: password, Department: department, Year: Number(year),
      Attendance: att, CGPA: cg, QuizAverage: "", SemMarks: "", StudyStreak: 0, XP: 100,
      ...Object.fromEntries(SUBJECTS.map((s) => [s, ""])),
      ...Object.fromEntries(Array.from({ length: 6 }, (_, i) => [`Att${i + 1}`, att])),
      RiskScore: score, RiskLevel: level, RegisteredAt: new Date().toISOString(),
    };
    appendRow(FILES.students, row, "Students");
    return res.json({ ok: true, user: studentToUser(row) });
  }
  if (role === "teacher") {
    const { name, teacherId, password } = req.body;
    if (!name?.trim() || !teacherId?.trim() || !password) return bad(res, "Please fill in all fields.");
    if (password.length < 6) return bad(res, "Password must be at least 6 characters.");
    const rows = readRows(FILES.teachers);
    const cleanId = teacherId.trim().toUpperCase();
    if (rows.some((r) => String(r.TeacherID).toUpperCase() === cleanId))
      return bad(res, "This Teacher ID is already registered. Please login instead.");
    const row = { TeacherID: cleanId, Name: name.trim(), Password: password, Department: "", RegisteredAt: new Date().toISOString() };
    appendRow(FILES.teachers, row, "Teachers");
    return res.json({ ok: true, user: teacherToUser(row) });
  }
  if (role === "admin") {
    const { name, email, password } = req.body;
    if (!name?.trim() || !email?.trim() || !password) return bad(res, "Please fill in all fields.");
    if (password.length < 6) return bad(res, "Password must be at least 6 characters.");
    const rows = readRows(FILES.admins);
    const cleanEmail = email.trim().toLowerCase();
    if (rows.some((r) => String(r.Email).toLowerCase() === cleanEmail))
      return bad(res, "This email is already registered. Please login instead.");
    const row = { Name: name.trim(), Email: cleanEmail, Password: password, RegisteredAt: new Date().toISOString() };
    appendRow(FILES.admins, row, "Admins");
    return res.json({ ok: true, user: adminToUser(row) });
  }
  return bad(res, "Unknown role.");
});

app.post("/api/auth/login", (req, res) => {
  const { role, identifier, password } = req.body || {};
  if (!identifier?.trim() || !password) return bad(res, "Please enter your credentials.");
  if (role === "teacher") {
    const row = readRows(FILES.teachers).find((r) => String(r.TeacherID).toUpperCase() === identifier.trim().toUpperCase());
    if (!row) return bad(res, "No teacher found with this Teacher ID. Please sign up first.", 401);
    if (String(row.Password) !== password) return bad(res, "Incorrect password. Please try again.", 401);
    return res.json({ ok: true, user: teacherToUser(row) });
  }
  if (role === "student") {
    const row = readRows(FILES.students).find((r) => String(r.Email).toLowerCase() === identifier.trim().toLowerCase());
    if (!row) return bad(res, "No account found with this email. Please sign up first.", 401);
    if (String(row.Password) !== password) return bad(res, "Incorrect password. Please try again.", 401);
    return res.json({ ok: true, user: studentToUser(row) });
  }
  if (role === "admin") {
    const row = readRows(FILES.admins).find((r) => String(r.Email).toLowerCase() === identifier.trim().toLowerCase());
    if (!row) return bad(res, "No admin account found with this email.", 401);
    if (String(row.Password) !== password) return bad(res, "Incorrect password. Please try again.", 401);
    return res.json({ ok: true, user: adminToUser(row) });
  }
  return bad(res, "Unknown role.");
});

app.get("/api/students", (_req, res) => res.json({ ok: true, students: allStudents() }));

/* Personalized dashboard — everything derived from the Excel files */
app.get("/api/dashboard", (req, res) => {
  const email = String(req.query.email || "").toLowerCase();
  const students = allStudents();
  const me = students.find((s) => s.email.toLowerCase() === email);
  if (!me) return bad(res, "Student not found.", 404);
  const months = monthLabels();
  const attendanceTrend = months.map((month, i) => ({
    month,
    attendance: me.attTrend[i] ?? me.attendance,
    classAvg: avg(students.map((s) => s.attTrend[i])),
  }));
  const subjects = SUBJECTS.map((sub) => ({
    subject: sub,
    marks: me.marks[sub],
    classAvg: avg(students.map((s) => s.marks[sub])),
  }));
  const sorted = [...students].sort((a, b) => b.xp - a.xp);
  const rank = sorted.findIndex((s) => s.email === me.email) + 1;
  const events = eventList();
  res.json({
    ok: true,
    student: me,
    attendanceTrend,
    subjects,
    rank,
    totalStudents: students.length,
    suggestions: suggestionsFor(me, events),
    events,
    notifications: notificationsFor("student", me, events),
  });
});

app.get("/api/leaderboard", (_req, res) => {
  const sorted = allStudents().sort((a, b) => b.xp - a.xp);
  res.json({
    ok: true,
    leaderboard: sorted.slice(0, 10).map((s, i) => ({
      rank: i + 1, name: s.name, email: s.email, xp: s.xp, streak: s.studyStreak, department: s.department,
    })),
    total: sorted.length,
  });
});

app.get("/api/events", (_req, res) => res.json({ ok: true, events: eventList() }));

app.get("/api/notifications", (req, res) => {
  const role = String(req.query.role || "student");
  const email = String(req.query.email || "").toLowerCase();
  const teacherId = String(req.query.teacherId || "");
  const me = role === "student" ? allStudents().find((s) => s.email.toLowerCase() === email) : null;
  res.json({ ok: true, notifications: notificationsFor(role, me, eventList(), teacherId) });
});

app.get("/api/opportunities", (req, res) => {
  const email = String(req.query.email || "").toLowerCase();
  const me = allStudents().find((s) => s.email.toLowerCase() === email);
  const marksAvg = me ? avg(SUBJECTS.map((s) => me.marks[s])) ?? me.cgpa * 10 : 60;
  const internships = readRows(FILES.internships).map((r, i) => ({
    id: i + 1, company: r.Company, role: r.Role, location: r.Location, stipend: r.Stipend,
    duration: r.Duration, minCgpa: Number(r.MinCGPA), skills: String(r.Skills).split(","),
    deadline: new Date(r.Deadline).toLocaleDateString("en-US", { month: "short", day: "2-digit" }),
    eligible: me ? me.cgpa >= Number(r.MinCGPA) : false,
  }));
  const jobs = readRows(FILES.jobs).map((r, i) => ({
    id: i + 1, company: r.Company, role: r.Role, location: r.Location, salary: r.Salary,
    skills: String(r.Skills).split(","),
    match: me ? clamp(Math.round(30 + me.cgpa * 4 + marksAvg * 0.35 + (me.attendance - 70) * 0.2), 35, 99) : 50,
  }));
  res.json({ ok: true, internships, jobs });
});

app.get("/api/certificates", (req, res) => {
  const email = String(req.query.email || "").toLowerCase();
  const certs = readRows(FILES.certificates)
    .filter((c) => String(c.Email).toLowerCase() === email)
    .map((c, i) => ({ id: i + 1, title: c.Title, issuer: c.Issuer, category: c.Category, date: c.Date }));
  res.json({ ok: true, certificates: certs });
});

app.get("/api/landing", (_req, res) => {
  const stats = Object.fromEntries(readRows(FILES.meta, "Stats").map((r) => [r.Key, r.Value]));
  const models = readRows(FILES.meta, "Models");
  const prod = models.find((m) => m.Status === "Production") ?? models[models.length - 1];
  const students = allStudents();
  const pct = (lvl) => (students.length ? Math.round((students.filter((s) => s.riskLevel === lvl).length / students.length) * 100) : 0);
  const top3 = [...students].sort((a, b) => b.riskScore - a.riskScore).slice(0, 3);
  res.json({
    ok: true,
    studentsMonitored: students.length,
    accuracy: prod ? Number(prod.Accuracy) : null,
    predictions: Number(stats.PredictionsMade) || 0,
    institutions: Number(stats.Institutions) || 0,
    riskDist: { low: pct("Low"), medium: pct("Medium"), high: pct("High") },
    sampleStudents: top3.map((s) => ({
      name: `${s.name.split(" ")[0]} ${s.name.split(" ")[1]?.[0] ?? ""}.`,
      score: s.riskScore,
      color: s.riskLevel === "Low" ? "#22C55E" : s.riskLevel === "Medium" ? "#F59E0B" : "#EF4444",
    })),
    testimonials: readRows(FILES.meta, "Testimonials").map((t) => ({ name: t.Name, role: t.Role, quote: t.Quote })),
  });
});

app.get("/api/admin/stats", (_req, res) => {
  const students = allStudents();
  const teachers = readRows(FILES.teachers);
  const models = readRows(FILES.meta, "Models");
  const prod = models.find((m) => m.Status === "Production") ?? models[models.length - 1];
  const byDept = {};
  students.forEach((s) => {
    byDept[s.department] ??= { dept: s.department, students: 0, high: 0, att: [], marks: [] };
    const d = byDept[s.department];
    d.students++;
    if (s.riskLevel === "High") d.high++;
    d.att.push(s.attendance);
    const m = avg(SUBJECTS.map((x) => s.marks[x]));
    if (m !== null) d.marks.push(m);
  });
  res.json({
    ok: true,
    totalStudents: students.length,
    totalTeachers: teachers.length,
    highRisk: students.filter((s) => s.riskLevel === "High").length,
    mediumRisk: students.filter((s) => s.riskLevel === "Medium").length,
    lowRisk: students.filter((s) => s.riskLevel === "Low").length,
    avgAttendance: avg(students.map((s) => s.attendance)),
    avgCgpa: avg(students.map((s) => s.cgpa)),
    modelAccuracy: prod ? Number(prod.Accuracy) : null,
    departments: Object.values(byDept).map((d) => ({
      dept: d.dept, students: d.students,
      highPct: d.students ? Math.round((d.high / d.students) * 100) : 0,
      avgAttendance: avg(d.att), avgScore: avg(d.marks),
    })),
  });
});

/* ---------- Admin: user management (writes straight to the Excel files) ---------- */
app.get("/api/users", (_req, res) => {
  res.json({
    ok: true,
    students: readRows(FILES.students).map((r) => ({ id: r.Email, name: r.Name, role: "Student", dept: r.Department, extra: `Year ${r.Year} · ${r.Attendance}% · CGPA ${r.CGPA}` })),
    teachers: readRows(FILES.teachers).map((r) => ({ id: r.TeacherID, name: r.Name, role: "Teacher", dept: r.Department || "—", extra: r.TeacherID })),
    admins: readRows(FILES.admins).map((r) => ({ id: r.Email, name: r.Name, role: "Admin", dept: "Administration", extra: r.Email })),
  });
});

app.delete("/api/users", (req, res) => {
  const { role, id } = req.body || {};
  if (role === "Student") {
    const rows = readRows(FILES.students).filter((r) => String(r.Email).toLowerCase() !== String(id).toLowerCase());
    writeRows(FILES.students, rows, "Students");
  } else if (role === "Teacher") {
    const rows = readRows(FILES.teachers).filter((r) => String(r.TeacherID).toUpperCase() !== String(id).toUpperCase());
    writeRows(FILES.teachers, rows, "Teachers");
  } else if (role === "Admin") {
    const rows = readRows(FILES.admins).filter((r) => String(r.Email).toLowerCase() !== String(id).toLowerCase());
    writeRows(FILES.admins, rows, "Admins");
  } else return bad(res, "Unknown role.");
  res.json({ ok: true });
});

app.put("/api/users", (req, res) => {
  const { role, id, name, dept } = req.body || {};
  if (role === "Student") {
    const rows = readRows(FILES.students);
    const r = rows.find((x) => String(x.Email).toLowerCase() === String(id).toLowerCase());
    if (!r) return bad(res, "User not found.", 404);
    if (name) r.Name = name;
    if (dept) r.Department = dept;
    writeRows(FILES.students, rows, "Students");
  } else if (role === "Teacher") {
    const rows = readRows(FILES.teachers);
    const r = rows.find((x) => String(x.TeacherID).toUpperCase() === String(id).toUpperCase());
    if (!r) return bad(res, "User not found.", 404);
    if (name) r.Name = name;
    if (dept) r.Department = dept;
    writeRows(FILES.teachers, rows, "Teachers");
  } else return bad(res, "Only students and teachers can be edited here.");
  res.json({ ok: true });
});

/* ---------- Teacher → student messages (messages.xlsx) ---------- */
app.post("/api/messages", (req, res) => {
  const { email, from, message } = req.body || {};
  if (!email?.trim() || !message?.trim()) return bad(res, "Student email and message are required.");
  const student = readRows(FILES.students).find((r) => String(r.Email).toLowerCase() === email.trim().toLowerCase());
  if (!student) return bad(res, "Student not found.", 404);
  appendRow(
    FILES.messages,
    { Email: email.trim().toLowerCase(), From: from?.trim() || "Teacher", Message: message.trim(), SentAt: new Date().toISOString(), Read: "No" },
    "Messages"
  );
  res.json({ ok: true });
});

app.get("/api/messages", (req, res) => {
  const email = String(req.query.email || "").toLowerCase();
  const messages = unreadMessagesFor(email).map((m) => ({
    from: m.From,
    message: m.Message,
    sentAt: m.SentAt ? new Date(m.SentAt).toLocaleString("en-US", { month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" }) : "",
  }));
  res.json({ ok: true, messages });
});

app.post("/api/messages/read", (req, res) => {
  const email = String(req.body?.email || "").toLowerCase();
  const rows = readRows(FILES.messages);
  rows.forEach((m) => {
    if (String(m.Email).toLowerCase() === email) m.Read = "Yes";
  });
  writeRows(FILES.messages, rows, "Messages");
  res.json({ ok: true });
});

/* ---------- Assignments workflow (assignments.xlsx + submissions.xlsx) ---------- */
const fmtDate = (iso) => (iso ? new Date(iso).toLocaleDateString("en-US", { month: "short", day: "2-digit", year: "numeric" }) : "");
const submissionsFor = (email) =>
  readRows(FILES.submissions).filter((r) => String(r.Email).toLowerCase() === String(email).toLowerCase());

function assignmentToJson(a) {
  return {
    id: a.ID,
    title: a.Title,
    description: a.Description,
    subject: a.Subject,
    dueDate: a.DueDate,
    dueLabel: fmtDate(a.DueDate),
    overdue: a.DueDate ? new Date(a.DueDate) < new Date(new Date().toISOString().slice(0, 10)) : false,
    attachment: a.Attachment || null,
    attachmentUrl: a.Attachment ? `/api/files/${a.Attachment}` : null,
    createdBy: a.CreatedBy,
    createdById: a.CreatedByID || "",
    createdAt: a.CreatedAt,
  };
}

/* Teacher: create & publish an assignment (optional attachment) */
app.post("/api/assignments", (req, res) => {
  const { title, description, subject, dueDate, createdBy, createdById, attachment } = req.body || {};
  if (!title?.trim() || !description?.trim() || !dueDate) return bad(res, "Title, description, and due date are required.");
  if (!createdById?.trim()) return bad(res, "Teacher ID is required to create an assignment.");
  let stored = "";
  if (attachment?.name && attachment?.data) {
    if (!ALLOWED_EXT.test(attachment.name)) return bad(res, "Attachment must be a PDF or Word document.");
    stored = saveUpload(attachment.name, attachment.data);
  }
  const row = {
    ID: `A${Date.now()}`,
    Title: title.trim(),
    Description: description.trim(),
    Subject: subject || "",
    DueDate: dueDate,
    Attachment: stored,
    CreatedBy: createdBy || "Teacher",
    CreatedByID: createdById.trim().toUpperCase(),
    CreatedAt: new Date().toISOString(),
  };
  appendRow(FILES.assignments, row, "Assignments");
  res.json({ ok: true, assignment: assignmentToJson(row) });
});

/* List assignments.
 * ?teacherId= — ONLY that teacher's own assignments (each teacher sees just what they created)
 * ?email=     — all assignments, joined with that student's submission status */
app.get("/api/assignments", (req, res) => {
  const email = String(req.query.email || "").toLowerCase();
  const teacherId = String(req.query.teacherId || "").toUpperCase();
  let rows = readRows(FILES.assignments);
  if (teacherId) rows = rows.filter((a) => String(a.CreatedByID).toUpperCase() === teacherId);
  const assignments = rows.map(assignmentToJson).sort((a, b) => (a.dueDate < b.dueDate ? -1 : 1));
  if (!email) return res.json({ ok: true, assignments });
  const subs = submissionsFor(email);
  res.json({
    ok: true,
    assignments: assignments.map((a) => {
      const s = subs.find((x) => String(x.AssignmentID) === String(a.id));
      return {
        ...a,
        status: s?.Status || "Not Started",
        submittedAt: s?.SubmittedAt ? fmtDate(s.SubmittedAt) : null,
        fileName: s?.FileName || null,
        fileUrl: s?.StoredFile ? `/api/files/${s.StoredFile}` : null,
        marks: s?.Marks === "" || s?.Marks === undefined ? null : Number(s.Marks),
        feedback: s?.Feedback || null,
      };
    }),
  });
});

/* Student: submit (or resubmit) a PDF / Word document */
app.post("/api/submissions", (req, res) => {
  const { assignmentId, email, file } = req.body || {};
  if (!assignmentId || !email?.trim() || !file?.name || !file?.data) return bad(res, "Assignment, student, and file are required.");
  if (!ALLOWED_EXT.test(file.name)) return bad(res, "Only PDF and Word documents (.pdf, .doc, .docx) are accepted.");
  const assignment = readRows(FILES.assignments).find((a) => String(a.ID) === String(assignmentId));
  if (!assignment) return bad(res, "Assignment not found.", 404);
  const student = readRows(FILES.students).find((r) => String(r.Email).toLowerCase() === email.trim().toLowerCase());
  if (!student) return bad(res, "Student not found.", 404);

  const stored = saveUpload(file.name, file.data);
  const rows = readRows(FILES.submissions);
  const existing = rows.find(
    (r) => String(r.AssignmentID) === String(assignmentId) && String(r.Email).toLowerCase() === email.trim().toLowerCase()
  );
  if (existing) {
    existing.FileName = file.name;
    existing.StoredFile = stored;
    existing.SubmittedAt = new Date().toISOString();
    existing.Status = "Submitted";
    existing.Marks = "";
    existing.Feedback = "";
  } else {
    rows.push({
      AssignmentID: assignmentId,
      Email: email.trim().toLowerCase(),
      FileName: file.name,
      StoredFile: stored,
      SubmittedAt: new Date().toISOString(),
      Status: "Submitted",
      Marks: "",
      Feedback: "",
    });
  }
  writeRows(FILES.submissions, rows, "Submissions");
  res.json({ ok: true });
});

/* Teacher: all students' submission status for one assignment */
app.get("/api/assignments/:id/submissions", (req, res) => {
  const id = String(req.params.id);
  const teacherId = String(req.query.teacherId || "").toUpperCase();
  const assignment = readRows(FILES.assignments).find((a) => String(a.ID) === id);
  if (!assignment) return bad(res, "Assignment not found.", 404);
  if (teacherId && String(assignment.CreatedByID).toUpperCase() !== teacherId)
    return bad(res, "You can only view submissions for assignments you created.", 403);
  const subs = readRows(FILES.submissions).filter((r) => String(r.AssignmentID) === id);
  const students = allStudents().map((s) => {
    const sub = subs.find((x) => String(x.Email).toLowerCase() === s.email.toLowerCase());
    return {
      name: s.name,
      email: s.email,
      department: s.department,
      year: s.year,
      status: sub?.Status || "Not Submitted",
      fileName: sub?.FileName || null,
      fileUrl: sub?.StoredFile ? `/api/files/${sub.StoredFile}` : null,
      submittedAt: sub?.SubmittedAt ? fmtDate(sub.SubmittedAt) : null,
      marks: sub?.Marks === "" || sub?.Marks === undefined ? null : Number(sub.Marks),
      feedback: sub?.Feedback || null,
    };
  });
  res.json({ ok: true, assignment: assignmentToJson(assignment), students });
});

/* Teacher: review — approve / reject / mark reviewed / grade with marks + feedback */
app.post("/api/submissions/review", (req, res) => {
  const { assignmentId, email, status, marks, feedback } = req.body || {};
  const allowed = ["Submitted", "Reviewed", "Approved", "Rejected", "Graded"];
  if (!assignmentId || !email || !allowed.includes(status)) return bad(res, `Status must be one of: ${allowed.join(", ")}.`);
  if (status === "Graded" && (marks === undefined || marks === null || marks === "")) return bad(res, "Marks are required to grade a submission.");
  const rows = readRows(FILES.submissions);
  const sub = rows.find(
    (r) => String(r.AssignmentID) === String(assignmentId) && String(r.Email).toLowerCase() === String(email).toLowerCase()
  );
  if (!sub || !sub.SubmittedAt) return bad(res, "No submission found for this student.", 404);
  sub.Status = status;
  if (marks !== undefined && marks !== null && marks !== "") sub.Marks = Number(marks);
  if (feedback !== undefined) sub.Feedback = String(feedback);
  writeRows(FILES.submissions, rows, "Submissions");
  res.json({ ok: true });
});

/* ---------- Saved resumes (resumes.xlsx) — one row per student, JSON in the Data column ---------- */
app.get("/api/resume", (req, res) => {
  const email = String(req.query.email || "").toLowerCase();
  const row = readRows(FILES.resumes).find((r) => String(r.Email).toLowerCase() === email);
  if (!row || !row.Data || row.Data === "{}") return res.json({ ok: true, resume: null });
  try {
    return res.json({ ok: true, resume: JSON.parse(row.Data) });
  } catch {
    return res.json({ ok: true, resume: null });
  }
});

app.post("/api/resume", (req, res) => {
  const { email, resume } = req.body || {};
  if (!email?.trim() || !resume) return bad(res, "Email and resume data are required.");
  const rows = readRows(FILES.resumes);
  const cleanEmail = email.trim().toLowerCase();
  const data = JSON.stringify(resume);
  const row = rows.find((r) => String(r.Email).toLowerCase() === cleanEmail);
  if (row) {
    row.Data = data;
    row.UpdatedAt = new Date().toISOString();
  } else {
    rows.push({ Email: cleanEmail, Data: data, UpdatedAt: new Date().toISOString() });
  }
  writeRows(FILES.resumes, rows, "Resumes");
  res.json({ ok: true });
});

/* ---------- ML model versions (meta.xlsx / Models sheet) ---------- */
app.get("/api/models", (_req, res) => res.json({ ok: true, models: readRows(FILES.meta, "Models") }));

app.post("/api/models/train", (_req, res) => {
  const models = readRows(FILES.meta, "Models");
  const last = models[models.length - 1];
  const lastVer = Number(String(last?.Version ?? "v2.0").replace("v", "")) || 2.0;
  const acc = clamp(Number(last?.Accuracy ?? 90) + rand(0.1, 0.6), 80, 97.5);
  models.forEach((m) => { if (m.Status === "Production") m.Status = "Archived"; });
  models.push({
    Version: `v${(lastVer + 0.1).toFixed(1)}`, Algorithm: "XGBoost",
    Accuracy: Math.round(acc * 10) / 10, F1: Math.round((acc / 100 - 0.03) * 100) / 100,
    Trained: new Date().toISOString().slice(0, 10), Status: "Production",
  });
  updateSheet(FILES.meta, "Models", models);
  res.json({ ok: true, model: models[models.length - 1] });
});

/* Serve the production build if present */
const DIST = path.join(ROOT, "dist");
if (fs.existsSync(DIST)) {
  app.use(express.static(DIST));
  app.get(/^(?!\/api).*/, (_req, res) => res.sendFile(path.join(DIST, "index.html")));
}

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`DropGuard AI API running on http://localhost:${PORT}`));
