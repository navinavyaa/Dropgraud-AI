import { createContext, useContext, useState, ReactNode } from "react";
import { Role } from "../data/mock";

export type RiskLevel = "Low" | "Medium" | "High";

export interface AuthUser {
  name: string;
  role: Role;
  avatar: string;
  email?: string;
  teacherId?: string;
  department?: string;
  year?: number;
  attendance?: number;
  cgpa?: number;
  quizAverage?: number | null;
  semMarks?: number | null;
  studyStreak?: number;
  xp?: number;
  marks?: Record<string, number | null>;
  attTrend?: (number | null)[];
  riskScore?: number;
  riskLevel?: RiskLevel;
}

export type StudentSignup = {
  role: "student";
  name: string;
  email: string;
  password: string;
  department: string;
  year: number;
  attendance: number;
  cgpa: number;
};
export type TeacherSignup = { role: "teacher"; name: string; teacherId: string; password: string };
export type AdminSignup = { role: "admin"; name: string; email: string; password: string };
export type SignupPayload = StudentSignup | TeacherSignup | AdminSignup;

type AuthResult = { ok: true; user: AuthUser } | { ok: false; error: string };

interface AuthContextType {
  user: AuthUser | null;
  login: (role: Role, identifier: string, password: string, remember: boolean) => Promise<AuthResult>;
  signup: (payload: SignupPayload, remember: boolean) => Promise<AuthResult>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  login: async () => ({ ok: false, error: "Auth not ready" }),
  signup: async () => ({ ok: false, error: "Auth not ready" }),
  logout: () => {},
});

const SESSION_KEY = "dropguard_session";

function readSession(): AuthUser | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY) ?? localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as AuthUser) : null;
  } catch {
    return null;
  }
}

function writeSession(u: AuthUser, remember: boolean) {
  const raw = JSON.stringify(u);
  if (remember) {
    localStorage.setItem(SESSION_KEY, raw);
    sessionStorage.removeItem(SESSION_KEY);
  } else {
    sessionStorage.setItem(SESSION_KEY, raw);
    localStorage.removeItem(SESSION_KEY);
  }
}

async function post(url: string, body: unknown): Promise<{ ok: boolean; user?: AuthUser; error?: string }> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return await res.json();
  } catch {
    return { ok: false, error: "Cannot reach the DropGuard server. Make sure it is running (npm run dev)." };
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(readSession);

  const signup = async (payload: SignupPayload, remember: boolean): Promise<AuthResult> => {
    const res = await post("/api/auth/signup", payload);
    if (!res.ok || !res.user) return { ok: false, error: res.error ?? "Signup failed." };
    writeSession(res.user, remember);
    setUser(res.user);
    return { ok: true, user: res.user };
  };

  const login = async (role: Role, identifier: string, password: string, remember: boolean): Promise<AuthResult> => {
    const res = await post("/api/auth/login", { role, identifier, password });
    if (!res.ok || !res.user) return { ok: false, error: res.error ?? "Login failed." };
    writeSession(res.user, remember);
    setUser(res.user);
    return { ok: true, user: res.user };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(SESSION_KEY);
    sessionStorage.removeItem(SESSION_KEY);
  };

  return <AuthContext.Provider value={{ user, login, signup, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
