import { ReactNode, useEffect, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import {
  LayoutDashboard, Users, GraduationCap, Calendar, BookOpen, Brain, Bot,
  BarChart3, Shield, AlertTriangle, Bell, Settings, FileText, Briefcase,
  Award, Trophy, Mail, Code2, MessageSquareText, Target, LogOut, Menu,
  ChevronLeft, X, ClipboardList, Database, Sparkles, FolderKanban, Mic,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { Role } from "../data/mock";
import { fetchNotifications, fetchUnreadMessages, markMessagesRead, NotificationItem, TeacherMessage } from "../lib/api";
import { MessageSquareWarning } from "lucide-react";

interface NavItem {
  to: string;
  label: string;
  icon: typeof LayoutDashboard;
}

const NAV: Record<Role, NavItem[]> = {
  student: [
    { to: "/student", label: "Dashboard", icon: LayoutDashboard },
    { to: "/student/resume", label: "AI Resume Builder", icon: FileText },
    { to: "/student/placement", label: "Placement Readiness", icon: GraduationCap },
    { to: "/student/interview", label: "Mock Interview", icon: Mic },
    { to: "/student/assignments", label: "Assignments", icon: ClipboardList },
    { to: "/student/chat", label: "AI Chat Assistant", icon: Bot },
  ],
  teacher: [
    { to: "/teacher", label: "Dashboard", icon: LayoutDashboard },
    { to: "/teacher/students", label: "Students", icon: Users },
    { to: "/teacher/assignments", label: "Assignments", icon: ClipboardList },
  ],
  admin: [
    { to: "/admin", label: "Dashboard", icon: LayoutDashboard },
    { to: "/admin/users", label: "Manage Users", icon: Users },
    { to: "/admin/analytics", label: "Institution Analytics", icon: BarChart3 },
    { to: "/admin/models", label: "AI Model Management", icon: Database },
  ],
};

const ROLE_COLORS: Record<Role, string> = {
  student: "#06B6D4",
  teacher: "#A855F7",
  admin: "#F59E0B",
};

export default function Layout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [teacherMsgs, setTeacherMsgs] = useState<TeacherMessage[]>([]);

  useEffect(() => {
    if (!user) return;
    fetchNotifications(user.role, user.email, user.teacherId).then(setNotifications).catch(() => {});
    // High-priority teacher messages: shown as a blocking alert on login for students
    if (user.role === "student" && user.email) {
      fetchUnreadMessages(user.email).then(setTeacherMsgs).catch(() => {});
    }
  }, [user]);

  const dismissMessages = () => {
    if (user?.email) markMessagesRead(user.email).catch(() => {});
    setTeacherMsgs([]);
  };

  const unread = notifications.length;

  if (!user) return null;
  const items = NAV[user.role];
  const roleColor = ROLE_COLORS[user.role];

  const sidebarContent = (isMobile: boolean) => (
    <div className="flex h-full flex-col">
      <div className="flex items-center justify-between px-4 py-5">
        <NavLink to="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
            <Shield size={18} className="text-white" />
          </div>
          {(!collapsed || isMobile) && (
            <span className="text-lg font-bold text-white">
              DropGuard <span className="gradient-text">AI</span>
            </span>
          )}
        </NavLink>
        {isMobile ? (
          <button onClick={() => setDrawerOpen(false)} aria-label="Close menu" className="text-muted hover:text-white">
            <X size={20} />
          </button>
        ) : (
          <button
            onClick={() => setCollapsed(!collapsed)}
            aria-label="Toggle sidebar"
            className="hidden text-muted transition-transform hover:text-white lg:block"
            style={{ transform: collapsed ? "rotate(180deg)" : "none" }}
          >
            <ChevronLeft size={18} />
          </button>
        )}
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 pb-4" aria-label="Main navigation">
        {items.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === `/${user.role}`}
            onClick={() => setDrawerOpen(false)}
            className={({ isActive }) =>
              `group flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all duration-200 ${
                isActive
                  ? "bg-gradient-to-r from-primary/30 to-accent/10 text-white shadow-[inset_0_0_0_1px_rgba(124,58,237,.4)]"
                  : "text-body hover:bg-white/5 hover:text-white"
              }`
            }
          >
            <item.icon size={19} className="shrink-0" />
            {(!collapsed || isMobile) && <span className="truncate">{item.label}</span>}
          </NavLink>
        ))}
      </nav>
      <div className="border-t border-soft p-3">
        <button
          onClick={() => {
            logout();
            navigate("/");
          }}
          className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-body transition-colors hover:bg-danger/15 hover:text-danger"
        >
          <LogOut size={19} />
          {(!collapsed || isMobile) && "Logout"}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen">
      {/* High-priority teacher message alert (blocking, shown on login) */}
      <AnimatePresence>
        {teacherMsgs.length > 0 && (
          <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm" role="alertdialog" aria-label="Message from your teacher">
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ duration: 0.25 }}
              className="glass-card w-full max-w-md border-2 !border-danger/50 p-6 shadow-[0_0_40px_rgba(239,68,68,.25)]"
            >
              <div className="mb-4 flex items-center gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-danger/20 text-danger">
                  <MessageSquareWarning size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">Message from your Teacher</h3>
                  <p className="text-xs text-danger">High priority · {teacherMsgs.length} unread</p>
                </div>
              </div>
              <div className="max-h-64 space-y-3 overflow-y-auto">
                {teacherMsgs.map((m, i) => (
                  <div key={i} className="rounded-xl border border-danger/25 bg-danger/10 p-4">
                    <p className="text-sm leading-relaxed text-white">{m.message}</p>
                    <p className="mt-2 text-xs text-muted">— {m.from}{m.sentAt ? ` · ${m.sentAt}` : ""}</p>
                  </div>
                ))}
              </div>
              <button className="btn-danger mt-5 w-full" onClick={dismissMessages}>
                Got it — mark as read
              </button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Desktop sidebar */}
      <motion.aside
        animate={{ width: collapsed ? 76 : 260 }}
        transition={{ duration: 0.3, ease: "easeInOut" }}
        className="sticky top-0 z-30 hidden h-screen shrink-0 border-r border-soft bg-sidebar/80 backdrop-blur-xl lg:block"
      >
        {sidebarContent(false)}
      </motion.aside>

      {/* Mobile drawer */}
      <AnimatePresence>
        {drawerOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-40 bg-black/60 lg:hidden"
              onClick={() => setDrawerOpen(false)}
            />
            <motion.aside
              initial={{ x: -280 }}
              animate={{ x: 0 }}
              exit={{ x: -280 }}
              transition={{ duration: 0.25 }}
              className="fixed inset-y-0 left-0 z-50 w-[260px] border-r border-soft bg-sidebar lg:hidden"
            >
              {sidebarContent(true)}
            </motion.aside>
          </>
        )}
      </AnimatePresence>

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Navbar */}
        <header className="sticky top-0 z-30 border-b border-soft bg-navbar/70 backdrop-blur-xl">
          <div className="flex items-center justify-between gap-3 px-4 py-3 md:px-6">
            <div className="flex items-center gap-3">
              <button
                className="text-body hover:text-white lg:hidden"
                onClick={() => setDrawerOpen(true)}
                aria-label="Open menu"
              >
                <Menu size={22} />
              </button>
              <span className="hidden text-sm text-muted sm:block">
                {new Date().toLocaleDateString("en-US", { weekday: "long", month: "long", day: "numeric", year: "numeric" })}
              </span>
            </div>
            <div className="flex items-center gap-3">
              <div className="relative">
                <button
                  onClick={() => setNotifOpen(!notifOpen)}
                  aria-label={`Notifications, ${unread} unread`}
                  className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-body transition-colors hover:bg-white/10 hover:text-white"
                >
                  <Bell size={19} />
                  {unread > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-danger px-1 text-[10px] font-bold text-white">
                      {unread}
                    </span>
                  )}
                </button>
                <AnimatePresence>
                  {notifOpen && (
                    <motion.div
                      initial={{ opacity: 0, y: 8, scale: 0.97 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 8, scale: 0.97 }}
                      transition={{ duration: 0.18 }}
                      className="glass-card absolute right-0 top-12 z-50 w-80 max-w-[85vw] p-3"
                    >
                      <p className="mb-2 px-2 text-sm font-bold text-white">Notification Center</p>
                      <div className="max-h-80 space-y-1 overflow-y-auto">
                        {notifications.map((n, i) => (
                          <div key={i} className="rounded-lg p-2.5 transition-colors hover:bg-white/5">
                            <div className="flex items-center gap-2">
                              <span
                                className="h-2 w-2 shrink-0 rounded-full"
                                style={{
                                  backgroundColor:
                                    n.type === "danger" ? "#EF4444" : n.type === "warning" ? "#F59E0B" : n.type === "success" ? "#22C55E" : "#06B6D4",
                                }}
                              />
                              <p className="flex-1 text-sm font-semibold text-white">{n.title}</p>
                            </div>
                            <p className="mt-1 pl-4 text-xs text-body">{n.body}</p>
                          </div>
                        ))}
                        {notifications.length === 0 && (
                          <p className="px-2 py-4 text-center text-xs text-muted">No notifications right now.</p>
                        )}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
              <span
                className="badge hidden capitalize sm:inline-flex"
                style={{ backgroundColor: `${roleColor}22`, color: roleColor }}
              >
                {user.role}
              </span>
              <div className="flex items-center gap-2.5">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-xl text-sm font-bold text-white"
                  style={{ background: `linear-gradient(135deg, ${roleColor}, #7C3AED)` }}
                >
                  {user.avatar}
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-semibold leading-tight text-white">{user.name}</p>
                  <p className="text-xs text-muted">{user.email}</p>
                </div>
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-4 md:p-6 lg:p-8" onClick={() => notifOpen && setNotifOpen(false)}>
          {children}
        </main>

        <footer className="border-t border-soft px-6 py-4 text-center text-xs text-muted">
          DROPGUARD AI – AI-Powered Student Dropout Prediction & Performance Monitoring © 2026
        </footer>
      </div>
    </div>
  );
}
