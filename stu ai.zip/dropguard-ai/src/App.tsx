import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ReactNode } from "react";
import { useAuth } from "./context/AuthContext";
import { Role } from "./data/mock";
import Layout from "./components/Layout";

import Landing from "./pages/Landing";
import Auth from "./pages/Auth";

import StudentDashboard from "./pages/student/StudentDashboard";
import ResumeBuilder from "./pages/student/ResumeBuilder";
import { PlacementReadiness } from "./pages/student/CareerPages";
import { MockInterview, Chatbot } from "./pages/student/PracticePages";
import Assignments from "./pages/student/Assignments";

import TeacherDashboard from "./pages/teacher/TeacherDashboard";
import { StudentsPage } from "./pages/teacher/TeacherPages";
import TeacherAssignments from "./pages/teacher/TeacherAssignments";

import AdminDashboard from "./pages/admin/AdminDashboard";
import { ManageUsers, InstitutionAnalytics, ModelManagement } from "./pages/admin/AdminPages";

function Protected({ role, children }: { role: Role; children: ReactNode }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  if (user.role !== role) return <Navigate to={`/${user.role}`} replace />;
  return <Layout>{children}</Layout>;
}

function Page({ children }: { children: ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
}

export default function App() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Auth mode="login" />} />
        <Route path="/signup" element={<Auth mode="signup" />} />

        <Route path="/student" element={<Protected role="student"><Page><StudentDashboard /></Page></Protected>} />
        <Route path="/student/resume" element={<Protected role="student"><Page><ResumeBuilder /></Page></Protected>} />
        <Route path="/student/placement" element={<Protected role="student"><Page><PlacementReadiness /></Page></Protected>} />
        <Route path="/student/interview" element={<Protected role="student"><Page><MockInterview /></Page></Protected>} />
        <Route path="/student/assignments" element={<Protected role="student"><Page><Assignments /></Page></Protected>} />
        <Route path="/student/chat" element={<Protected role="student"><Page><Chatbot /></Page></Protected>} />

        <Route path="/teacher" element={<Protected role="teacher"><Page><TeacherDashboard /></Page></Protected>} />
        <Route path="/teacher/students" element={<Protected role="teacher"><Page><StudentsPage /></Page></Protected>} />
        <Route path="/teacher/assignments" element={<Protected role="teacher"><Page><TeacherAssignments /></Page></Protected>} />

        <Route path="/admin" element={<Protected role="admin"><Page><AdminDashboard /></Page></Protected>} />
        <Route path="/admin/users" element={<Protected role="admin"><Page><ManageUsers /></Page></Protected>} />
        <Route path="/admin/analytics" element={<Protected role="admin"><Page><InstitutionAnalytics /></Page></Protected>} />
        <Route path="/admin/models" element={<Protected role="admin"><Page><ModelManagement /></Page></Protected>} />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AnimatePresence>
  );
}
