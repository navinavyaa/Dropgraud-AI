import { useCallback, useRef, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Toast } from "../components/ui";

export function useToast(): [JSX.Element, (msg: string) => void] {
  const [msg, setMsg] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout>>();

  const show = useCallback((m: string) => {
    setMsg(m);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setMsg(null), 2600);
  }, []);

  const el = <AnimatePresence>{msg && <Toast message={msg} />}</AnimatePresence>;
  return [el, show];
}
