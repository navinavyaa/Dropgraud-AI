/**
 * No mock data lives here anymore.
 * All application data comes from the Excel files in /data via the API server
 * (see server/index.mjs and src/lib/api.ts).
 */
export type Role = "student" | "teacher" | "admin";
