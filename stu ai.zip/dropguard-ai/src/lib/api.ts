export type RiskLevel = "Low" | "Medium" | "High";

export interface RegisteredStudent {
  role: "student";
  name: string;
  email: string;
  avatar: string;
  department: string;
  year: number;
  attendance: number;
  cgpa: number;
  quizAverage: number | null;
  semMarks: number | null;
  studyStreak: number;
  xp: number;
  marks: Record<string, number | null>;
  attTrend: (number | null)[];
  riskScore: number;
  riskLevel: RiskLevel;
}

export interface EventItem { title: string; type: string; color: string; iso: string; date: string; daysAway: number }
export interface Suggestion { tag: string; text: string }
export interface NotificationItem { type: string; title: string; body: string }

export interface DashboardData {
  student: RegisteredStudent;
  attendanceTrend: { month: string; attendance: number | null; classAvg: number | null }[];
  subjects: { subject: string; marks: number | null; classAvg: number | null }[];
  rank: number;
  totalStudents: number;
  suggestions: Suggestion[];
  events: EventItem[];
  notifications: NotificationItem[];
}

export interface LeaderboardEntry { rank: number; name: string; email: string; xp: number; streak: number; department: string }
export interface Internship { id: number; company: string; role: string; location: string; stipend: string; duration: string; minCgpa: number; skills: string[]; deadline: string; eligible: boolean }
export interface Job { id: number; company: string; role: string; location: string; salary: string; skills: string[]; match: number }
export interface Certificate { id: number; title: string; issuer: string; category: string; date: string }
export interface LandingData {
  studentsMonitored: number; accuracy: number | null; predictions: number; institutions: number;
  riskDist: { low: number; medium: number; high: number };
  sampleStudents: { name: string; score: number; color: string }[];
  testimonials: { name: string; role: string; quote: string }[];
}
export interface AdminStats {
  totalStudents: number; totalTeachers: number; highRisk: number; mediumRisk: number; lowRisk: number;
  avgAttendance: number | null; avgCgpa: number | null; modelAccuracy: number | null;
  departments: { dept: string; students: number; highPct: number; avgAttendance: number | null; avgScore: number | null }[];
}
export interface AdminUser { id: string; name: string; role: string; dept: string; extra: string }
export interface ModelVersion { Version: string; Algorithm: string; Accuracy: number; F1: number; Trained: string; Status: string }

async function get<T>(url: string): Promise<T> {
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok || !data.ok) throw new Error(data.error ?? "Request failed");
  return data as T;
}

export const fetchStudents = () => get<{ students: RegisteredStudent[] }>("/api/students").then((d) => d.students);
export const fetchDashboard = (email: string) => get<DashboardData & { ok: boolean }>(`/api/dashboard?email=${encodeURIComponent(email)}`);
export const fetchLeaderboard = () => get<{ leaderboard: LeaderboardEntry[]; total: number }>("/api/leaderboard");
export const fetchEvents = () => get<{ events: EventItem[] }>("/api/events").then((d) => d.events);
export const fetchNotifications = (role: string, email?: string, teacherId?: string) =>
  get<{ notifications: NotificationItem[] }>(
    `/api/notifications?role=${role}&email=${encodeURIComponent(email ?? "")}&teacherId=${encodeURIComponent(teacherId ?? "")}`
  ).then((d) => d.notifications);
export const fetchOpportunities = (email: string) =>
  get<{ internships: Internship[]; jobs: Job[] }>(`/api/opportunities?email=${encodeURIComponent(email)}`);
export const fetchCertificates = (email: string) =>
  get<{ certificates: Certificate[] }>(`/api/certificates?email=${encodeURIComponent(email)}`).then((d) => d.certificates);
export const fetchLanding = () => get<LandingData>("/api/landing");
export const fetchAdminStats = () => get<AdminStats>("/api/admin/stats");
export const fetchUsers = () => get<{ students: AdminUser[]; teachers: AdminUser[]; admins: AdminUser[] }>("/api/users");
export const fetchModels = () => get<{ models: ModelVersion[] }>("/api/models").then((d) => d.models);

export async function apiMutate(url: string, method: string, body: unknown): Promise<{ ok: boolean; error?: string }> {
  const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  return res.json();
}

export const deleteUser = (role: string, id: string) => apiMutate("/api/users", "DELETE", { role, id });
export const updateUser = (role: string, id: string, name: string, dept: string) => apiMutate("/api/users", "PUT", { role, id, name, dept });
export const trainModel = () =>
  apiMutate("/api/models/train", "POST", {}) as Promise<{ ok: boolean; model?: ModelVersion; error?: string }>;

export interface TeacherMessage { from: string; message: string; sentAt: string }

export const fetchUnreadMessages = (email: string) =>
  get<{ messages: TeacherMessage[] }>(`/api/messages?email=${encodeURIComponent(email)}`).then((d) => d.messages);
export const sendStudentMessage = (email: string, from: string, message: string) =>
  apiMutate("/api/messages", "POST", { email, from, message });
export const markMessagesRead = (email: string) => apiMutate("/api/messages/read", "POST", { email });

/* ---------- Assignments ---------- */
export type SubmissionStatus = "Not Started" | "Not Submitted" | "Submitted" | "Reviewed" | "Approved" | "Rejected" | "Graded";

export interface Assignment {
  id: string; title: string; description: string; subject: string;
  dueDate: string; dueLabel: string; overdue: boolean;
  attachment: string | null; attachmentUrl: string | null;
  createdBy: string; createdById: string; createdAt: string;
  status?: SubmissionStatus; submittedAt?: string | null;
  fileName?: string | null; fileUrl?: string | null;
  marks?: number | null; feedback?: string | null;
}

export interface SubmissionRow {
  name: string; email: string; department: string; year: number;
  status: SubmissionStatus; fileName: string | null; fileUrl: string | null;
  submittedAt: string | null; marks: number | null; feedback: string | null;
}

export const fetchAssignments = (email?: string) =>
  get<{ assignments: Assignment[] }>(`/api/assignments${email ? `?email=${encodeURIComponent(email)}` : ""}`).then((d) => d.assignments);
export const fetchTeacherAssignments = (teacherId: string) =>
  get<{ assignments: Assignment[] }>(`/api/assignments?teacherId=${encodeURIComponent(teacherId)}`).then((d) => d.assignments);
export const createAssignment = (payload: {
  title: string; description: string; subject: string; dueDate: string; createdBy: string; createdById: string;
  attachment?: { name: string; data: string };
}) => apiMutate("/api/assignments", "POST", payload);
export const submitAssignment = (assignmentId: string, email: string, file: { name: string; data: string }) =>
  apiMutate("/api/submissions", "POST", { assignmentId, email, file });
export const fetchAssignmentSubmissions = (id: string, teacherId?: string) =>
  get<{ assignment: Assignment; students: SubmissionRow[] }>(
    `/api/assignments/${encodeURIComponent(id)}/submissions${teacherId ? `?teacherId=${encodeURIComponent(teacherId)}` : ""}`
  );
export const reviewSubmission = (assignmentId: string, email: string, status: string, marks: number | null, feedback: string) =>
  apiMutate("/api/submissions/review", "POST", { assignmentId, email, status, marks, feedback });

export const statusColor = (s: string) =>
  s === "Graded" ? "#22C55E" : s === "Approved" ? "#22C55E" : s === "Reviewed" ? "#06B6D4" : s === "Submitted" ? "#A855F7" : s === "Rejected" ? "#EF4444" : "#94A3B8";

/** Read a File into base64 (without the data: prefix) */
export const fileToBase64 = (file: File) =>
  new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(",")[1] ?? "");
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

export const fetchSavedResume = <T,>(email: string) =>
  get<{ resume: T | null }>(`/api/resume?email=${encodeURIComponent(email)}`).then((d) => d.resume);
export const saveResumeData = (email: string, resume: unknown) => apiMutate("/api/resume", "POST", { email, resume });

export const riskColor = (level: RiskLevel) =>
  level === "Low" ? "#22C55E" : level === "Medium" ? "#F59E0B" : "#EF4444";

export const SERVER_ERROR = "Cannot reach the DropGuard server. Make sure it is running (npm run dev).";
