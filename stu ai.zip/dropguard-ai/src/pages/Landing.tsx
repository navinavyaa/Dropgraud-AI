import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Shield, Brain, BarChart3, Bell, Bot, GraduationCap, Users, Calendar,
  FileText, Target, Sparkles, ChevronDown, ArrowRight, Activity, Database,
  LineChart, CheckCircle2,
} from "lucide-react";
import { useEffect, useState } from "react";
import { fetchLanding, LandingData } from "../lib/api";

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-60px" },
  transition: { duration: 0.55 },
};


function HeroIllustration({ live }: { live: LandingData | null }) {
  const dist = [
    { label: "Low", value: live ? `${live.riskDist.low}%` : "…", color: "#22C55E" },
    { label: "Medium", value: live ? `${live.riskDist.medium}%` : "…", color: "#F59E0B" },
    { label: "High", value: live ? `${live.riskDist.high}%` : "…", color: "#EF4444" },
  ];
  const sample = live?.sampleStudents ?? [];
  return (
    <motion.div
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.7, delay: 0.2 }}
      className="relative mx-auto w-full max-w-md"
    >
      <div className="glass-card animate-float !p-5">
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/25 text-link">
              <Brain size={16} />
            </div>
            <span className="text-sm font-semibold text-white">Risk Prediction Engine</span>
          </div>
          <span className="badge bg-success/20 text-success">
            <span className="h-1.5 w-1.5 animate-pulseSoft rounded-full bg-success" /> Live
          </span>
        </div>
        <div className="mb-4 grid grid-cols-3 gap-2">
          {dist.map((r) => (
            <div key={r.label} className="rounded-xl bg-white/5 p-3 text-center">
              <p className="text-lg font-bold" style={{ color: r.color }}>{r.value}</p>
              <p className="text-[11px] text-muted">{r.label} Risk</p>
            </div>
          ))}
        </div>
        <div className="space-y-2.5">
          {sample.map((s, i) => (
            <div key={s.name + i} className="flex items-center gap-3">
              <span className="w-16 truncate text-xs text-body">{s.name}</span>
              <div className="h-2 flex-1 overflow-hidden rounded-full bg-white/10">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${s.score}%` }}
                  transition={{ duration: 1, delay: 0.6 + i * 0.2 }}
                  className="h-full rounded-full"
                  style={{ backgroundColor: s.color }}
                />
              </div>
              <span className="w-8 text-right text-xs font-semibold" style={{ color: s.color }}>{s.score}</span>
            </div>
          ))}
          {sample.length === 0 && <p className="py-2 text-center text-xs text-muted">Connecting to live data…</p>}
        </div>
      </div>
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.1 }}
        className="glass-card absolute -right-4 -top-8 hidden !p-4 sm:block"
      >
        <div className="flex items-center gap-2">
          <CheckCircle2 size={16} className="text-success" />
          <p className="text-xs font-semibold text-white">{live ? `${live.riskDist.low}% of students on track` : "…"}</p>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function Landing() {
  const [live, setLive] = useState<LandingData | null>(null);

  useEffect(() => {
    fetchLanding().then(setLive).catch(() => {});
  }, []);

  // Live values only — computed from the Excel data, nothing fabricated
  const stats = [
    { label: "Registered Students", value: live ? String(live.studentsMonitored) : "…", icon: Users },
    { label: "Students On Track (Low Risk)", value: live ? `${live.riskDist.low}%` : "…", icon: Activity },
  ];
  return (
    <div className="min-h-screen">
      {/* Navbar */}
      <nav className="sticky top-0 z-40 border-b border-soft bg-navbar/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3.5 md:px-6">
          <Link to="/" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
              <Shield size={18} className="text-white" />
            </div>
            <span className="text-lg font-bold text-white">
              DropGuard <span className="gradient-text">AI</span>
            </span>
          </Link>
          <div className="flex items-center gap-3">
            <Link to="/login" className="btn-ghost !py-2 text-sm">Login</Link>
            <Link to="/signup" className="btn-primary !py-2 text-sm">Sign Up</Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="mx-auto max-w-7xl px-4 pb-20 pt-16 md:px-6 md:pt-24">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <motion.span
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="badge mb-5 border border-primary/30 bg-primary/15 text-link"
            >
              <Sparkles size={12} /> AI-Powered Education Intelligence
            </motion.span>
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-4xl font-extrabold leading-tight text-white md:text-5xl lg:text-[48px]"
            >
              Predict Student Dropout <span className="gradient-text">Before It Happens</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="mt-5 max-w-xl text-lg text-body"
            >
              Monitor attendance, academic performance, behavior, and risk factors using Artificial Intelligence.
            </motion.p>
          </div>
          <HeroIllustration live={live} />
        </div>

        {/* Stats — live from the Excel data */}
        <div className="mx-auto mt-24 grid max-w-3xl grid-cols-1 gap-4 sm:grid-cols-2">
          {stats.map((s, i) => (
            <motion.div key={s.label} {...fadeUp} transition={{ duration: 0.5, delay: i * 0.1 }} className="glass-card glass-card-hover p-6 text-center">
              <s.icon size={26} className="mx-auto mb-3 text-link" />
              <p className="text-3xl font-bold text-white">{s.value}</p>
              <p className="mt-1 text-sm text-muted">{s.label}</p>
            </motion.div>
          ))}
        </div>
      </section>





      {/* Footer */}
      <footer className="border-t border-soft bg-navbar/60">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-6 px-4 py-10 md:px-6">
          <div>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent">
                <Shield size={15} className="text-white" />
              </div>
              <span className="font-bold text-white">DropGuard <span className="gradient-text">AI</span></span>
            </div>
            <p className="mt-3 text-sm text-muted">AI-Powered Student Dropout Prediction & Performance Monitoring.</p>
          </div>
        </div>
        <div className="border-t border-soft py-5 text-center text-xs text-muted">
          © 2026 DROPGUARD AI – AI-Powered Student Dropout Prediction & Performance Monitoring. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
