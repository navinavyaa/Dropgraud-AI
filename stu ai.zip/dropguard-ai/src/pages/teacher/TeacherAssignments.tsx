import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import {
  ClipboardList, Paperclip, Send, ChevronDown, ExternalLink, CheckCircle2,
  XCircle, Eye, GraduationCap, RefreshCw,
} from "lucide-react";
import { Card, PageHeader, Badge, ProgressBar } from "../../components/ui";
import { useToast } from "../../hooks/useToast";
import { useAuth } from "../../context/AuthContext";
import {
  fetchTeacherAssignments, createAssignment, fetchAssignmentSubmissions, reviewSubmission,
  fileToBase64, statusColor, Assignment, SubmissionRow, SERVER_ERROR,
} from "../../lib/api";

const SUBJECTS = ["Maths", "DSA", "DBMS", "OS", "Networks", "AIML", "Other"];
const MAX_MB = 10;

export default function TeacherAssignments() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[] | null>(null);
  const [error, setError] = useState("");
  const [toastEl, toast] = useToast();

  // create form
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("DBMS");
  const [dueDate, setDueDate] = useState("");
  const [description, setDescription] = useState("");
  const [attachment, setAttachment] = useState<File | null>(null);
  const [publishing, setPublishing] = useState(false);
  const [formError, setFormError] = useState("");

  // submissions view
  const [openId, setOpenId] = useState<string | null>(null);
  const [rows, setRows] = useState<SubmissionRow[]>([]);
  const [loadingRows, setLoadingRows] = useState(false);
  const [edits, setEdits] = useState<Record<string, { marks: string; feedback: string }>>({});

  const load = () => {
    if (!user?.teacherId) return;
    fetchTeacherAssignments(user.teacherId)
      .then((a) => { setAssignments([...a].sort((x, y) => (x.createdAt < y.createdAt ? 1 : -1))); setError(""); })
      .catch(() => setError(SERVER_ERROR));
  };
  useEffect(load, [user?.teacherId]); // eslint-disable-line react-hooks/exhaustive-deps

  const openSubmissions = (id: string) => {
    if (openId === id) return setOpenId(null);
    setOpenId(id);
    setLoadingRows(true);
    fetchAssignmentSubmissions(id, user?.teacherId)
      .then((d) => {
        setRows(d.students);
        setEdits(Object.fromEntries(d.students.map((s) => [s.email, { marks: s.marks?.toString() ?? "", feedback: s.feedback ?? "" }])));
      })
      .catch(() => toast(SERVER_ERROR))
      .finally(() => setLoadingRows(false));
  };

  const publish = async () => {
    setFormError("");
    if (!title.trim() || !description.trim() || !dueDate) {
      setFormError("Title, description, and due date are required.");
      return;
    }
    if (attachment && !/\.(pdf|doc|docx)$/i.test(attachment.name)) {
      setFormError("Attachment must be a PDF or Word document.");
      return;
    }
    if (attachment && attachment.size > MAX_MB * 1024 * 1024) {
      setFormError(`Attachment too large — maximum ${MAX_MB} MB.`);
      return;
    }
    setPublishing(true);
    try {
      const payload = {
        title, description, subject, dueDate,
        createdBy: user ? `${user.name}${user.teacherId ? ` (${user.teacherId})` : ""}` : "Teacher",
        createdById: user?.teacherId ?? "",
        ...(attachment ? { attachment: { name: attachment.name, data: await fileToBase64(attachment) } } : {}),
      };
      const res = await createAssignment(payload);
      if (!res.ok) setFormError(res.error ?? "Failed to publish.");
      else {
        toast("Assignment published — all students have been notified");
        setTitle(""); setDescription(""); setDueDate(""); setAttachment(null);
        load();
      }
    } catch {
      setFormError(SERVER_ERROR);
    } finally {
      setPublishing(false);
    }
  };

  const review = async (a: Assignment, s: SubmissionRow, status: string) => {
    const edit = edits[s.email] ?? { marks: "", feedback: "" };
    if (status === "Graded" && edit.marks === "") {
      toast("Enter marks before grading");
      return;
    }
    const res = await reviewSubmission(a.id, s.email, status, edit.marks === "" ? null : Number(edit.marks), edit.feedback);
    if (!res.ok) return toast(res.error ?? "Update failed");
    toast(`${s.name.split(" ")[0]}'s submission marked ${status}`);
    setOpenId(a.id); // refresh rows
    fetchAssignmentSubmissions(a.id, user?.teacherId).then((d) => setRows(d.students)).catch(() => {});
  };

  const progress = (a: Assignment) => {
    if (openId !== a.id || !rows.length) return null;
    const submitted = rows.filter((r) => r.status !== "Not Submitted").length;
    return { submitted, total: rows.length };
  };

  return (
    <div>
      {toastEl}
      <PageHeader
        title="Assignment Management"
        subtitle="Create assignments, notify students, and review every submission."
        icon={ClipboardList}
        actions={<button className="btn-ghost !py-2 text-sm" onClick={load}><RefreshCw size={15} /> Refresh</button>}
      />

      {error && <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">{error}</p>}

      {/* Create & publish */}
      <Card hover={false} className="mb-6">
        <h3 className="mb-4 font-semibold text-white">Create New Assignment</h3>
        <div className="grid gap-4 md:grid-cols-3">
          <div className="md:col-span-2">
            <label htmlFor="a-title" className="label">Title</label>
            <input id="a-title" className="input" placeholder="e.g. OS — Process Scheduling Worksheet" value={title} onChange={(e) => setTitle(e.target.value)} />
          </div>
          <div>
            <label htmlFor="a-subject" className="label">Subject</label>
            <select id="a-subject" className="input" value={subject} onChange={(e) => setSubject(e.target.value)}>
              {SUBJECTS.map((s) => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div className="mt-4">
          <label htmlFor="a-desc" className="label">Description</label>
          <textarea id="a-desc" className="input min-h-[90px]" placeholder="What should students do, and how should they submit it?" value={description} onChange={(e) => setDescription(e.target.value)} />
        </div>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <div>
            <label htmlFor="a-due" className="label">Due Date</label>
            <input id="a-due" type="date" className="input" value={dueDate} min={new Date().toISOString().slice(0, 10)} onChange={(e) => setDueDate(e.target.value)} />
          </div>
          <div className="md:col-span-2">
            <label className="label">Attachment (optional — PDF/Word)</label>
            <div className="flex items-center gap-3">
              <label className="btn-ghost cursor-pointer !py-2 text-sm">
                <Paperclip size={15} /> {attachment ? attachment.name : "Choose file"}
                <input type="file" accept=".pdf,.doc,.docx" className="hidden" onChange={(e) => setAttachment(e.target.files?.[0] ?? null)} />
              </label>
              {attachment && <button className="text-xs text-danger hover:underline" onClick={() => setAttachment(null)}>Remove</button>}
            </div>
          </div>
        </div>
        {formError && <p className="mt-3 rounded-xl border border-danger/30 bg-danger/10 px-3.5 py-2.5 text-sm text-danger" role="alert">{formError}</p>}
        <button className="btn-primary mt-4" onClick={publish} disabled={publishing}>
          <Send size={15} /> {publishing ? "Publishing…" : "Publish & Notify Students"}
        </button>
      </Card>

      {/* Published assignments + submission tracking — only YOUR assignments are listed */}
      <h3 className="mb-3 font-semibold text-white">Your Published Assignments {assignments && `(${assignments.length})`}</h3>
      {!assignments && !error && <p className="animate-pulseSoft text-sm text-muted">Loading…</p>}
      <div className="space-y-4">
        {assignments?.map((a) => {
          const p = progress(a);
          return (
            <Card key={a.id} hover={false} className="!p-0">
              <button className="flex w-full flex-wrap items-center justify-between gap-3 p-5 text-left" onClick={() => openSubmissions(a.id)} aria-expanded={openId === a.id}>
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-bold text-white">{a.title}</p>
                    {a.subject && <Badge color="#06B6D4">{a.subject}</Badge>}
                  </div>
                  <p className="mt-0.5 text-xs text-muted">Due {a.dueLabel} · by {a.createdBy}</p>
                </div>
                <div className="flex items-center gap-3">
                  {a.attachmentUrl && (
                    <a href={a.attachmentUrl} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()} className="text-link hover:text-white" aria-label="Open attachment">
                      <Paperclip size={16} />
                    </a>
                  )}
                  <ChevronDown size={18} className={`text-muted transition-transform ${openId === a.id ? "rotate-180" : ""}`} />
                </div>
              </button>

              {openId === a.id && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="border-t border-soft p-5">
                  {loadingRows ? (
                    <p className="animate-pulseSoft py-4 text-center text-sm text-muted">Loading submissions…</p>
                  ) : (
                    <>
                      {p && (
                        <div className="mb-4">
                          <div className="mb-1 flex justify-between text-xs text-muted">
                            <span>{p.submitted} of {p.total} students submitted</span>
                            <span>{Math.round((p.submitted / p.total) * 100)}%</span>
                          </div>
                          <ProgressBar value={(p.submitted / p.total) * 100} color="#7C3AED" />
                        </div>
                      )}
                      <div className="overflow-x-auto">
                        <table className="w-full text-left text-sm">
                          <thead>
                            <tr className="border-b border-soft text-xs uppercase tracking-wide text-muted">
                              <th className="pb-2 pr-3">Student</th>
                              <th className="pb-2 pr-3">Status</th>
                              <th className="pb-2 pr-3">Document</th>
                              <th className="pb-2 pr-3">Marks</th>
                              <th className="pb-2 pr-3">Feedback</th>
                              <th className="pb-2 text-right">Actions</th>
                            </tr>
                          </thead>
                          <tbody>
                            {rows.map((s) => (
                              <tr key={s.email} className="border-b border-soft/50 align-top transition-colors hover:bg-white/5">
                                <td className="py-2.5 pr-3">
                                  <p className="font-medium text-white">{s.name}</p>
                                  <p className="text-[11px] text-muted">{s.department} · Y{s.year}</p>
                                </td>
                                <td className="py-2.5 pr-3">
                                  <Badge color={statusColor(s.status)}>{s.status}</Badge>
                                  {s.submittedAt && <p className="mt-1 text-[11px] text-muted">{s.submittedAt}</p>}
                                </td>
                                <td className="py-2.5 pr-3">
                                  {s.fileUrl ? (
                                    <a href={s.fileUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 text-xs text-link hover:text-white">
                                      <ExternalLink size={12} /> {s.fileName}
                                    </a>
                                  ) : (
                                    <span className="text-xs text-muted">—</span>
                                  )}
                                </td>
                                <td className="py-2.5 pr-3">
                                  <input
                                    type="number"
                                    className="input !w-20 !px-2 !py-1.5 text-xs"
                                    placeholder="—"
                                    aria-label={`Marks for ${s.name}`}
                                    disabled={s.status === "Not Submitted"}
                                    value={edits[s.email]?.marks ?? ""}
                                    onChange={(e) => setEdits((x) => ({ ...x, [s.email]: { ...(x[s.email] ?? { feedback: "" }), marks: e.target.value } }))}
                                  />
                                </td>
                                <td className="py-2.5 pr-3">
                                  <input
                                    className="input !min-w-[160px] !px-2 !py-1.5 text-xs"
                                    placeholder="Feedback…"
                                    aria-label={`Feedback for ${s.name}`}
                                    disabled={s.status === "Not Submitted"}
                                    value={edits[s.email]?.feedback ?? ""}
                                    onChange={(e) => setEdits((x) => ({ ...x, [s.email]: { ...(x[s.email] ?? { marks: "" }), feedback: e.target.value } }))}
                                  />
                                </td>
                                <td className="py-2.5 text-right">
                                  {s.status === "Not Submitted" ? (
                                    <span className="text-xs text-muted">Awaiting</span>
                                  ) : (
                                    <div className="flex justify-end gap-1">
                                      <button title="Mark Reviewed" aria-label={`Mark ${s.name} reviewed`} className="rounded-lg bg-accent/15 p-1.5 text-accent hover:bg-accent/30" onClick={() => review(a, s, "Reviewed")}><Eye size={14} /></button>
                                      <button title="Approve" aria-label={`Approve ${s.name}`} className="rounded-lg bg-success/15 p-1.5 text-success hover:bg-success/30" onClick={() => review(a, s, "Approved")}><CheckCircle2 size={14} /></button>
                                      <button title="Reject" aria-label={`Reject ${s.name}`} className="rounded-lg bg-danger/15 p-1.5 text-danger hover:bg-danger/30" onClick={() => review(a, s, "Rejected")}><XCircle size={14} /></button>
                                      <button title="Grade (uses marks field)" aria-label={`Grade ${s.name}`} className="rounded-lg bg-primary/15 p-1.5 text-link hover:bg-primary/30" onClick={() => review(a, s, "Graded")}><GraduationCap size={14} /></button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                      <p className="mt-3 text-[11px] text-muted">
                        <Eye size={11} className="inline" /> Reviewed · <CheckCircle2 size={11} className="inline text-success" /> Approve · <XCircle size={11} className="inline text-danger" /> Reject · <GraduationCap size={11} className="inline text-link" /> Grade (requires marks). Feedback saves with any action.
                      </p>
                    </>
                  )}
                </motion.div>
              )}
            </Card>
          );
        })}
        {assignments?.length === 0 && <Card hover={false}><p className="py-6 text-center text-sm text-muted">No assignments yet — create your first one above.</p></Card>}
      </div>
    </div>
  );
}
