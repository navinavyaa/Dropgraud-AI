import { useEffect, useMemo, useState } from "react";
import { Users, Search, MessageSquarePlus, Send } from "lucide-react";
import { Card, PageHeader, Badge, Modal } from "../../components/ui";
import { useAuth } from "../../context/AuthContext";
import { useToast } from "../../hooks/useToast";
import { fetchStudents, sendStudentMessage, riskColor, RegisteredStudent, SERVER_ERROR } from "../../lib/api";

export function StudentsPage() {
  const { user } = useAuth();
  const [students, setStudents] = useState<RegisteredStudent[] | null>(null);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [risk, setRisk] = useState("All");
  const [msgTarget, setMsgTarget] = useState<RegisteredStudent | null>(null);
  const [msgText, setMsgText] = useState("");
  const [sending, setSending] = useState(false);
  const [toastEl, toast] = useToast();

  useEffect(() => {
    fetchStudents()
      .then(setStudents)
      .catch(() => setError(SERVER_ERROR));
  }, []);

  const filtered = useMemo(() => {
    if (!students) return [];
    const q = query.toLowerCase();
    return students.filter(
      (s) =>
        (risk === "All" || s.riskLevel === risk) &&
        (s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q))
    );
  }, [students, query, risk]);

  const presets = msgTarget
    ? [
        `Hi ${msgTarget.name.split(" ")[0]}, your attendance is at ${msgTarget.attendance}%. Please meet me this week to plan how to bring it up.`,
        `Hi ${msgTarget.name.split(" ")[0]}, I'd like to schedule a quick mentoring session. Please see me after class tomorrow.`,
        `Good work, ${msgTarget.name.split(" ")[0]}! Your recent progress is noticeable — keep it up.`,
      ]
    : [];

  const send = async () => {
    if (!msgTarget || !msgText.trim()) return;
    setSending(true);
    const from = user ? `${user.name}${user.teacherId ? ` (${user.teacherId})` : ""}` : "Teacher";
    const res = await sendStudentMessage(msgTarget.email, from, msgText.trim());
    setSending(false);
    if (!res.ok) return toast(res.error ?? "Failed to send message");
    toast(`Message sent — ${msgTarget.name.split(" ")[0]} will see it as a high-priority alert on next login`);
    setMsgTarget(null);
    setMsgText("");
  };

  return (
    <div>
      {toastEl}
      <PageHeader
        title="Students"
        subtitle={
          students
            ? `${filtered.length} of ${students.length} registered students`
            : "Loading registered students…"
        }
        icon={Users}
      />

      {error && (
        <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">
          {error}
        </p>
      )}

      <Card hover={false} className="!p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input
              className="input !pl-10"
              placeholder="Search by name or email…"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              aria-label="Search students"
            />
          </div>
          {["All", "Low", "Medium", "High"].map((r) => (
            <button
              key={r}
              onClick={() => setRisk(r)}
              className={`badge ${risk === r ? "bg-primary/25 text-link border border-primary/40" : "bg-white/5 text-muted hover:text-white"}`}
            >
              {r}
            </button>
          ))}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-soft text-xs uppercase tracking-wide text-muted">
                <th className="pb-3 pr-4">Student Name</th>
                <th className="pb-3 pr-4">Department / Year</th>
                <th className="pb-3 pr-4">Attendance %</th>
                <th className="pb-3 pr-4">CGPA</th>
                <th className="pb-3 pr-4">Dropout Risk</th>
                <th className="pb-3 text-right">Message</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((s) => (
                <tr key={s.email} className="border-b border-soft/50 transition-colors hover:bg-white/5">
                  <td className="py-3 pr-4">
                    <p className="font-medium text-white">{s.name}</p>
                    <p className="text-xs text-muted">{s.email}</p>
                  </td>
                  <td className="py-3 pr-4 text-body">{s.department} · Year {s.year}</td>
                  <td className="py-3 pr-4">
                    <span className={s.attendance < 75 ? "font-semibold text-danger" : "text-body"}>{s.attendance}%</span>
                  </td>
                  <td className="py-3 pr-4 text-body">{s.cgpa}</td>
                  <td className="py-3 pr-4">
                    <Badge color={riskColor(s.riskLevel)}>{s.riskScore} · {s.riskLevel}</Badge>
                  </td>
                  <td className="py-3 text-right">
                    <button
                      aria-label={`Send message to ${s.name}`}
                      title="Send message"
                      className="rounded-lg bg-primary/15 p-2 text-link transition-colors hover:bg-primary/30 hover:text-white"
                      onClick={() => { setMsgTarget(s); setMsgText(""); }}
                    >
                      <MessageSquarePlus size={16} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {students && filtered.length === 0 && (
            <p className="py-8 text-center text-sm text-muted">No students match your filters.</p>
          )}
          {!students && !error && <p className="py-8 text-center text-sm text-muted">Loading…</p>}
        </div>
      </Card>

      {/* Compose message modal */}
      <Modal open={!!msgTarget} onClose={() => setMsgTarget(null)} title={`Message ${msgTarget?.name ?? ""}`}>
        {msgTarget && (
          <div>
            <p className="mb-3 text-xs text-muted">
              {msgTarget.email} · {msgTarget.department} Year {msgTarget.year} · Risk {msgTarget.riskScore} ({msgTarget.riskLevel})
            </p>
            <div className="mb-3 space-y-2">
              <p className="label !mb-1">Quick templates</p>
              {presets.map((p, i) => (
                <button
                  key={i}
                  onClick={() => setMsgText(p)}
                  className="block w-full rounded-lg bg-white/5 px-3 py-2 text-left text-xs text-body transition-colors hover:bg-primary/15 hover:text-white"
                >
                  {p}
                </button>
              ))}
            </div>
            <label htmlFor="msg" className="label">Message</label>
            <textarea
              id="msg"
              className="input min-h-[110px]"
              placeholder="Type your message to the student…"
              value={msgText}
              onChange={(e) => setMsgText(e.target.value)}
            />
            <p className="mt-2 text-xs text-muted">
              The student will see this as a high-priority alert the next time they log in. Stored in messages.xlsx.
            </p>
            <button className="btn-primary mt-4 w-full" onClick={send} disabled={sending || !msgText.trim()}>
              <Send size={15} /> {sending ? "Sending…" : "Send Message"}
            </button>
          </div>
        )}
      </Modal>
    </div>
  );
}
