import { useEffect, useState } from "react";
import { Users, ShieldCheck, ShieldAlert, AlertTriangle } from "lucide-react";
import { StatCard, PageHeader } from "../../components/ui";
import { useAuth } from "../../context/AuthContext";
import { fetchStudents, RegisteredStudent } from "../../lib/api";

export default function TeacherDashboard() {
  const { user } = useAuth();
  const [students, setStudents] = useState<RegisteredStudent[] | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchStudents()
      .then(setStudents)
      .catch(() => setError("Cannot reach the DropGuard server. Make sure it is running (npm run dev)."));
  }, []);

  const total = students?.length ?? 0;
  const count = (level: string) => students?.filter((s) => s.riskLevel === level).length ?? 0;
  const pct = (n: number) => (total ? `${Math.round((n / total) * 100)}% of students` : "—");

  const low = count("Low");
  const medium = count("Medium");
  const high = count("High");

  return (
    <div>
      <PageHeader
        title="Teacher Dashboard"
        subtitle={`Welcome, ${user?.name ?? "Teacher"}${user?.teacherId ? ` (${user.teacherId})` : ""} — live view of all registered students.`}
        icon={Users}
      />

      {error && (
        <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">
          {error}
        </p>
      )}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          icon={Users}
          label="Total Students"
          value={students ? String(total) : "…"}
          sub="Registered via Student Sign Up"
          color="#7C3AED"
        />
        <StatCard
          icon={ShieldCheck}
          label="Low Risk"
          value={students ? String(low) : "…"}
          sub={pct(low)}
          color="#22C55E"
          delay={0.08}
        />
        <StatCard
          icon={ShieldAlert}
          label="Medium Risk"
          value={students ? String(medium) : "…"}
          sub={pct(medium)}
          color="#F59E0B"
          delay={0.16}
        />
        <StatCard
          icon={AlertTriangle}
          label="High Risk"
          value={students ? String(high) : "…"}
          sub={pct(high)}
          color="#EF4444"
          delay={0.24}
        />
      </div>
    </div>
  );
}
