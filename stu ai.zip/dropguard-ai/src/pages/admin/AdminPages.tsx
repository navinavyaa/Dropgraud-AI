import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  Users, BarChart3, Database, Settings, Search, UserPlus, Pencil, Trash2,
  Brain, Upload, CheckCircle2, Shield, Bell, Mail, HardDriveDownload, Sparkles,
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend,
} from "recharts";
import { Card, PageHeader, Badge, ProgressBar, Modal, AIBadge } from "../../components/ui";
import { useToast } from "../../hooks/useToast";
import {
  fetchUsers, fetchAdminStats, fetchModels, deleteUser, updateUser, trainModel, apiMutate,
  AdminUser, AdminStats, ModelVersion, SERVER_ERROR,
} from "../../lib/api";

const tooltipStyle = { backgroundColor: "#1E293B", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "12px", color: "#fff" };
const DEPTS = ["CSE", "ECE", "IT", "MECH", "CIVIL", "EEE"];

/* ---------------- Manage Users — reads & writes the Excel files ---------------- */

export function ManageUsers() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState("All");
  const [editing, setEditing] = useState<AdminUser | null>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ name: "", id: "", role: "Student", dept: "CSE", year: 1, attendance: 80, cgpa: 7.5 });
  const [toastEl, toast] = useToast();

  const load = () =>
    fetchUsers()
      .then((d) => setUsers([...d.students, ...d.teachers, ...d.admins]))
      .catch(() => setError(SERVER_ERROR));

  useEffect(() => { load(); }, []);

  const filtered = useMemo(
    () => users.filter((u) => (roleFilter === "All" || u.role === roleFilter) && (u.name.toLowerCase().includes(query.toLowerCase()) || u.id.toLowerCase().includes(query.toLowerCase()))),
    [users, query, roleFilter]
  );

  const roleColor = (r: string) => (r === "Admin" ? "#F59E0B" : r === "Teacher" ? "#A855F7" : "#06B6D4");

  const submit = async () => {
    if (!form.name || !form.id) return;
    if (adding) {
      const payload =
        form.role === "Student"
          ? { role: "student", name: form.name, email: form.id, password: "student123", department: form.dept, year: form.year, attendance: form.attendance, cgpa: form.cgpa }
          : form.role === "Teacher"
          ? { role: "teacher", name: form.name, teacherId: form.id, password: "teach123" }
          : { role: "admin", name: form.name, email: form.id, password: "admin123" };
      const res = await apiMutate("/api/auth/signup", "POST", payload);
      if (!res.ok) return toast(res.error ?? "Failed to add user");
      toast(`${form.name} added — default password ${form.role === "Student" ? "student123" : form.role === "Teacher" ? "teach123" : "admin123"}`);
    } else if (editing) {
      const res = await updateUser(editing.role, editing.id, form.name, form.dept);
      if (!res.ok) return toast(res.error ?? "Failed to update user");
      toast("User updated in Excel");
    }
    setAdding(false);
    setEditing(null);
    load();
  };

  return (
    <div>
      {toastEl}
      <PageHeader
        title="Manage Users"
        subtitle={`${users.length} users — loaded from the Excel files`}
        icon={Users}
        actions={<button className="btn-primary !py-2 text-sm" onClick={() => { setForm({ name: "", id: "", role: "Student", dept: "CSE", year: 1, attendance: 80, cgpa: 7.5 }); setAdding(true); }}><UserPlus size={15} /> Add User</button>}
      />
      {error && <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger">{error}</p>}
      <Card hover={false} className="!p-4">
        <div className="mb-4 flex flex-wrap items-center gap-3">
          <div className="relative min-w-[220px] flex-1">
            <Search size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
            <input className="input !pl-10" placeholder="Search users…" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Search users" />
          </div>
          {["All", "Student", "Teacher", "Admin"].map((r) => (
            <button key={r} onClick={() => setRoleFilter(r)} className={`badge ${roleFilter === r ? "bg-primary/25 text-link border border-primary/40" : "bg-white/5 text-muted hover:text-white"}`}>{r}</button>
          ))}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-soft text-xs uppercase tracking-wide text-muted">
                <th className="pb-3 pr-4">User</th>
                <th className="pb-3 pr-4">Role</th>
                <th className="pb-3 pr-4">Department</th>
                <th className="pb-3 pr-4">Details</th>
                <th className="pb-3 text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={`${u.role}-${u.id}`} className="border-b border-soft/50 transition-colors hover:bg-white/5">
                  <td className="py-3 pr-4">
                    <p className="font-medium text-white">{u.name}</p>
                    <p className="text-xs text-muted">{u.id}</p>
                  </td>
                  <td className="py-3 pr-4"><Badge color={roleColor(u.role)}>{u.role}</Badge></td>
                  <td className="py-3 pr-4 text-body">{u.dept}</td>
                  <td className="py-3 pr-4 text-xs text-muted">{u.extra}</td>
                  <td className="py-3 text-right">
                    <button aria-label={`Edit ${u.name}`} className="mr-1 rounded-lg p-2 text-muted transition-colors hover:bg-white/10 hover:text-white" onClick={() => { setEditing(u); setForm({ ...form, name: u.name, id: u.id, role: u.role, dept: u.dept === "—" ? "CSE" : u.dept }); }}>
                      <Pencil size={15} />
                    </button>
                    <button
                      aria-label={`Delete ${u.name}`}
                      className="rounded-lg p-2 text-muted transition-colors hover:bg-danger/15 hover:text-danger"
                      onClick={async () => {
                        const res = await deleteUser(u.role, u.id);
                        toast(res.ok ? `${u.name} removed from Excel` : res.error ?? "Delete failed");
                        load();
                      }}
                    >
                      <Trash2 size={15} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {users.length === 0 && !error && <p className="py-8 text-center text-sm text-muted">Loading from Excel…</p>}
        </div>
      </Card>

      <Modal open={adding || !!editing} onClose={() => { setAdding(false); setEditing(null); }} title={adding ? "Add User" : `Edit ${editing?.role ?? "User"}`}>
        <div className="space-y-3">
          {adding && (
            <div>
              <label className="label">Role</label>
              <select className="input" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
                {["Student", "Teacher", "Admin"].map((r) => <option key={r}>{r}</option>)}
              </select>
            </div>
          )}
          <div><label className="label">Name</label><input className="input" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div>
            <label className="label">{form.role === "Teacher" ? "Teacher ID" : "Email"}</label>
            <input className="input" value={form.id} disabled={!adding} onChange={(e) => setForm({ ...form, id: e.target.value })} />
          </div>
          {form.role !== "Admin" && (
            <div>
              <label className="label">Department</label>
              <select className="input" value={form.dept} onChange={(e) => setForm({ ...form, dept: e.target.value })}>
                {DEPTS.map((d) => <option key={d}>{d}</option>)}
              </select>
            </div>
          )}
          {adding && form.role === "Student" && (
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="label">Year</label>
                <select className="input" value={form.year} onChange={(e) => setForm({ ...form, year: Number(e.target.value) })}>
                  {[1, 2, 3, 4].map((y) => <option key={y} value={y}>{y}</option>)}
                </select>
              </div>
              <div><label className="label">Attendance %</label><input type="number" className="input" value={form.attendance} onChange={(e) => setForm({ ...form, attendance: Number(e.target.value) })} /></div>
              <div><label className="label">CGPA</label><input type="number" step="0.1" className="input" value={form.cgpa} onChange={(e) => setForm({ ...form, cgpa: Number(e.target.value) })} /></div>
            </div>
          )}
          <button className="btn-primary w-full" onClick={submit}>{adding ? "Add to Excel" : "Save Changes"}</button>
        </div>
      </Modal>
    </div>
  );
}

/* ---------------- Institution Analytics — computed from students.xlsx ---------------- */

export function InstitutionAnalytics() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchAdminStats().then(setStats).catch(() => setError(SERVER_ERROR));
  }, []);

  const insights = useMemo(() => {
    if (!stats) return [];
    const out: string[] = [];
    const worstDept = [...stats.departments].sort((a, b) => b.highPct - a.highPct)[0];
    const bestDept = [...stats.departments].sort((a, b) => (b.avgScore ?? 0) - (a.avgScore ?? 0))[0];
    if (worstDept) out.push(`${worstDept.dept} has the highest risk concentration (${worstDept.highPct}% high risk) — recommend a department-level attendance review.`);
    if (bestDept?.avgScore != null) out.push(`${bestDept.dept} leads academically with an average score of ${bestDept.avgScore}%.`);
    out.push(`${stats.highRisk} of ${stats.totalStudents} students are high risk; institution-wide average attendance is ${stats.avgAttendance}% and average CGPA is ${stats.avgCgpa}.`);
    return out;
  }, [stats]);

  return (
    <div>
      <PageHeader title="Institution Analytics" subtitle="All figures computed live from students.xlsx." icon={BarChart3} />
      {error && <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger">{error}</p>}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h3 className="mb-3 font-semibold text-white">Department Performance</h3>
          {stats && (
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={stats.departments.map((d) => ({ dept: d.dept, avgScore: d.avgScore ?? 0, attendance: d.avgAttendance ?? 0 }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="dept" stroke="#94A3B8" fontSize={12} />
                <YAxis stroke="#94A3B8" fontSize={12} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="avgScore" name="Avg Marks %" fill="#7C3AED" radius={[6, 6, 0, 0]} />
                <Bar dataKey="attendance" name="Attendance %" fill="#06B6D4" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </Card>
        <Card>
          <h3 className="mb-3 font-semibold text-white">High-Risk % by Department</h3>
          <div className="space-y-4 pt-2">
            {stats?.departments.map((d) => {
              const color = d.highPct < 10 ? "#22C55E" : d.highPct < 20 ? "#F59E0B" : "#EF4444";
              return (
                <div key={d.dept}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="text-white">{d.dept} <span className="text-xs text-muted">({d.students} students)</span></span>
                    <span className="font-semibold" style={{ color }}>{d.highPct}%</span>
                  </div>
                  <ProgressBar value={d.highPct} color={color} />
                </div>
              );
            })}
          </div>
        </Card>
      </div>
      <Card className="mt-6" hover={false}>
        <div className="mb-3 flex items-center gap-2">
          <Sparkles size={17} className="text-link" />
          <h3 className="font-semibold text-white">AI Institutional Insights</h3>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {insights.map((t, i) => (
            <div key={i} className="rounded-xl border border-primary/20 bg-primary/10 p-4 text-sm text-body">{t}</div>
          ))}
        </div>
      </Card>
    </div>
  );
}

/* ---------------- AI Model Management — meta.xlsx / Models sheet ---------------- */

export function ModelManagement() {
  const [models, setModels] = useState<ModelVersion[]>([]);
  const [training, setTraining] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState("");
  const [toastEl, toast] = useToast();

  const load = () => fetchModels().then(setModels).catch(() => setError(SERVER_ERROR));
  useEffect(() => { load(); }, []);

  const prod = models.find((m) => m.Status === "Production");

  const train = () => {
    setTraining(true);
    setProgress(0);
    const iv = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(iv);
          trainModel().then((res) => {
            setTraining(false);
            toast(res.ok && res.model ? `Model ${res.model.Version} trained — accuracy ${res.model.Accuracy}% (saved to meta.xlsx)` : "Training failed");
            load();
          });
          return 100;
        }
        return p + 4;
      });
    }, 100);
  };

  return (
    <div>
      {toastEl}
      <PageHeader
        title="AI Model Management"
        subtitle="Model versions live in meta.xlsx — training appends a new version."
        icon={Database}
        actions={
          <button className="btn-primary !py-2 text-sm" onClick={train} disabled={training}>
            <Brain size={15} /> {training ? "Training…" : "Train New Model"}
          </button>
        }
      />
      {error && <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger">{error}</p>}
      {training && (
        <Card hover={false} className="mb-6">
          <div className="mb-2 flex items-center justify-between text-sm">
            <span className="font-semibold text-white"><span className="animate-pulseSoft">Training new model (XGBoost)…</span></span>
            <span className="text-link">{progress}%</span>
          </div>
          <ProgressBar value={progress} color="#7C3AED" />
        </Card>
      )}
      <div className="grid gap-4 md:grid-cols-3">
        {[
          { label: "Production Accuracy", value: prod ? `${prod.Accuracy}%` : "…", color: "#22C55E" },
          { label: "Production F1 Score", value: prod ? String(prod.F1) : "…", color: "#06B6D4" },
          { label: "Total Versions", value: models.length ? String(models.length) : "…", color: "#A855F7" },
        ].map((m, i) => (
          <motion.div key={m.label} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }} className="glass-card glass-card-hover p-5 text-center">
            <p className="text-2xl font-bold" style={{ color: m.color }}>{m.value}</p>
            <p className="mt-1 text-xs text-muted">{m.label}</p>
          </motion.div>
        ))}
      </div>
      <Card className="mt-6" hover={false}>
        <h3 className="mb-4 font-semibold text-white">Model Version History (meta.xlsx)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-soft text-xs uppercase tracking-wide text-muted">
                <th className="pb-3 pr-4">Version</th>
                <th className="pb-3 pr-4">Algorithm</th>
                <th className="pb-3 pr-4">Accuracy</th>
                <th className="pb-3 pr-4">F1</th>
                <th className="pb-3 pr-4">Trained</th>
                <th className="pb-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {[...models].reverse().map((m) => (
                <tr key={m.Version} className="border-b border-soft/50 transition-colors hover:bg-white/5">
                  <td className="py-3 pr-4 font-semibold text-white">{m.Version}</td>
                  <td className="py-3 pr-4 text-body">{m.Algorithm}</td>
                  <td className="py-3 pr-4 text-body">{m.Accuracy}%</td>
                  <td className="py-3 pr-4 text-body">{m.F1}</td>
                  <td className="py-3 pr-4 text-muted">{m.Trained}</td>
                  <td className="py-3"><Badge color={m.Status === "Production" ? "#22C55E" : "#94A3B8"}>{m.Status}</Badge></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <Card className="mt-6" hover={false}>
        <div className="mb-3"><AIBadge text="Risk formula (single source of truth)" /></div>
        <p className="text-sm text-body">
          score = 100 − (0.55 × attendance + 4.5 × CGPA) · <span className="text-success">Low &lt; 20</span> ≤ <span className="text-warning">Medium &lt; 40</span> ≤ <span className="text-danger">High</span>
        </p>
        <p className="mt-2 text-xs text-muted">Defined once in server/index.mjs — every dashboard uses the same calculation.</p>
      </Card>
    </div>
  );
}
