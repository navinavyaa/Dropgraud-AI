import { useEffect, useState } from "react";
import {
  Users, GraduationCap, Brain, AlertTriangle, Shield, CalendarCheck,
} from "lucide-react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { Card, StatCard, PageHeader, Badge, ProgressBar } from "../../components/ui";
import { fetchAdminStats, AdminStats, SERVER_ERROR } from "../../lib/api";

const tooltipStyle = { backgroundColor: "#1E293B", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "12px", color: "#fff" };

export default function AdminDashboard() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    fetchAdminStats().then(setStats).catch(() => setError(SERVER_ERROR));
  }, []);

  const riskDistribution = stats
    ? [
        { name: "Low Risk", value: stats.lowRisk, color: "#22C55E" },
        { name: "Medium Risk", value: stats.mediumRisk, color: "#F59E0B" },
        { name: "High Risk", value: stats.highRisk, color: "#EF4444" },
      ]
    : [];

  return (
    <div>
      <PageHeader title="Admin Dashboard" subtitle="Institution-wide overview — computed live from the Excel files." icon={Shield} />

      {error && <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">{error}</p>}

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard icon={GraduationCap} label="Total Students" value={stats ? String(stats.totalStudents) : "…"} sub="students.xlsx" color="#7C3AED" />
        <StatCard icon={Users} label="Teachers" value={stats ? String(stats.totalTeachers) : "…"} sub="teachers.xlsx" color="#A855F7" delay={0.06} />
        <StatCard icon={CalendarCheck} label="Avg Attendance" value={stats?.avgAttendance != null ? `${stats.avgAttendance}%` : "…"} sub="All students" color="#06B6D4" delay={0.12} />
        <StatCard icon={Brain} label="ML Accuracy" value={stats?.modelAccuracy != null ? `${stats.modelAccuracy}%` : "…"} sub="Production model" color="#22C55E" delay={0.18} />
        <StatCard icon={AlertTriangle} label="High Risk" value={stats ? String(stats.highRisk) : "…"} sub="Flagged students" color="#EF4444" delay={0.24} />
        <StatCard icon={GraduationCap} label="Avg CGPA" value={stats?.avgCgpa != null ? String(stats.avgCgpa) : "…"} sub="All students" color="#F59E0B" delay={0.3} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <Card>
          <h3 className="mb-2 font-semibold text-white">Risk Distribution</h3>
          {stats && (
            <ResponsiveContainer width="100%" height={240}>
              <PieChart>
                <Pie data={riskDistribution} dataKey="value" nameKey="name" innerRadius={55} outerRadius={85} paddingAngle={4}>
                  {riskDistribution.map((r) => <Cell key={r.name} fill={r.color} />)}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </Card>

        <Card className="lg:col-span-2" hover={false}>
          <h3 className="mb-4 font-semibold text-white">Department Risk Overview</h3>
          <div className="space-y-3.5">
            {stats?.departments.map((d) => {
              const color = d.highPct < 10 ? "#22C55E" : d.highPct < 20 ? "#F59E0B" : "#EF4444";
              return (
                <div key={d.dept} className="flex items-center gap-4">
                  <span className="w-16 truncate text-sm text-white">{d.dept}</span>
                  <div className="flex-1"><ProgressBar value={d.highPct} color={color} /></div>
                  <Badge color={color}>{d.highPct}% high risk</Badge>
                  <span className="hidden w-32 text-right text-xs text-muted sm:block">
                    {d.students} students · att {d.avgAttendance ?? "—"}%
                  </span>
                </div>
              );
            })}
            {!stats && !error && <p className="py-6 text-center text-sm text-muted">Loading from Excel…</p>}
          </div>
        </Card>
      </div>
    </div>
  );
}
