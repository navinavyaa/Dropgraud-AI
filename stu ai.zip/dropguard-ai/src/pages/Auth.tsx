import { FormEvent, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import {
  Shield, Brain, Bot, BarChart3, Sparkles, GraduationCap, Users, Settings2,
  Eye, EyeOff, CheckCircle2,
} from "lucide-react";
import { useAuth, SignupPayload } from "../context/AuthContext";
import { Role } from "../data/mock";

const roleMeta: { role: Role; label: string; icon: typeof GraduationCap }[] = [
  { role: "student", label: "Student", icon: GraduationCap },
  { role: "teacher", label: "Teacher", icon: Users },
  { role: "admin", label: "Admin", icon: Settings2 },
];

const DEPARTMENTS = ["CSE", "ECE", "IT", "MECH", "CIVIL", "EEE"];

export default function Auth({ mode }: { mode: "login" | "signup" }) {
  const { login, signup } = useAuth();
  const navigate = useNavigate();
  const [role, setRole] = useState<Role>("student");

  // shared fields
  const [name, setName] = useState("");
  const [identifier, setIdentifier] = useState(""); // email (student/admin) or Teacher ID (teacher)
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [remember, setRemember] = useState(true);

  // student signup fields
  const [department, setDepartment] = useState("CSE");
  const [year, setYear] = useState(1);
  const [attendance, setAttendance] = useState("");
  const [cgpa, setCgpa] = useState("");

  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [busy, setBusy] = useState(false);

  const idLabel = role === "teacher" ? "Teacher ID" : role === "student" ? "College Email" : "Email";
  const idPlaceholder = role === "teacher" ? "e.g. T021" : "you@college.edu";

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setError("");
    setInfo("");

    if (mode === "signup" && password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    setBusy(true);
    if (mode === "signup") {
      let payload: SignupPayload;
      if (role === "student") {
        payload = {
          role: "student", name, email: identifier, password,
          department, year, attendance: Number(attendance), cgpa: Number(cgpa),
        };
      } else if (role === "teacher") {
        payload = { role: "teacher", name, teacherId: identifier, password };
      } else {
        payload = { role: "admin", name, email: identifier, password };
      }
      const res = await signup(payload, remember);
      setBusy(false);
      if (!res.ok) return setError(res.error);
      navigate(`/${res.user.role}`);
    } else {
      const res = await login(role, identifier, password, remember);
      setBusy(false);
      if (!res.ok) return setError(res.error);
      navigate(`/${res.user.role}`);
    }
  };

  return (
    <div className="flex min-h-screen">
      {/* Left illustration panel */}
      <div className="relative hidden flex-1 items-center justify-center overflow-hidden bg-sidebar/50 lg:flex">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/25 via-transparent to-accent/20" />
        <div className="relative z-10 max-w-md px-10">
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <Link to="/" className="mb-10 flex items-center gap-2.5">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
                <Shield size={22} className="text-white" />
              </div>
              <span className="text-2xl font-bold text-white">DropGuard <span className="gradient-text">AI</span></span>
            </Link>
            <h1 className="text-3xl font-bold leading-snug text-white">
              Intelligent Student Dropout Prediction & Performance Monitoring
            </h1>
            <p className="mt-4 text-body">
              One AI platform for risk prediction, performance analytics, career guidance, and placement preparation.
            </p>
            <div className="mt-10 space-y-4">
              {[
                { icon: Brain, text: "94.2% prediction accuracy with continuously retrained ML models" },
                { icon: BarChart3, text: "Live dashboards for students, teachers, and administrators" },
                { icon: Bot, text: "24×7 AI assistant for academics and placement prep" },
              ].map((f, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.3 + i * 0.15 }}
                  className="flex items-center gap-3 rounded-xl bg-white/5 p-3.5 backdrop-blur"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/25 text-link">
                    <f.icon size={19} />
                  </div>
                  <p className="text-sm text-body">{f.text}</p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
        <div className="absolute -bottom-24 -left-24 h-72 w-72 rounded-full bg-primary/20 blur-3xl" />
        <div className="absolute -right-20 top-10 h-64 w-64 rounded-full bg-accent/15 blur-3xl" />
      </div>

      {/* Right form panel */}
      <div className="flex flex-1 items-center justify-center px-4 py-10">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
          className="glass-card w-full max-w-md p-8"
        >
          <Link to="/" className="mb-6 flex items-center gap-2 lg:hidden">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent">
              <Shield size={17} className="text-white" />
            </div>
            <span className="text-lg font-bold text-white">DropGuard <span className="gradient-text">AI</span></span>
          </Link>
          <h2 className="text-2xl font-bold text-white">{mode === "login" ? "Welcome back" : "Create your account"}</h2>
          <p className="mt-1 text-sm text-muted">
            {mode === "login"
              ? role === "teacher"
                ? "Login with your assigned Teacher ID and password."
                : "Login with your registered credentials."
              : role === "student"
              ? "Register with your academic details — your dashboard is built from them."
              : "Register once to access your portal."}
          </p>

          {/* Role selector */}
          <div className="mt-6 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Select role">
            {roleMeta.map((r) => (
              <button
                key={r.role}
                type="button"
                role="radio"
                aria-checked={role === r.role}
                onClick={() => { setRole(r.role); setError(""); setIdentifier(""); }}
                className={`rounded-xl border p-3 text-center transition-all ${
                  role === r.role
                    ? "border-primary/60 bg-primary/15 shadow-glow"
                    : "border-soft bg-white/5 hover:bg-white/10"
                }`}
              >
                <r.icon size={20} className={`mx-auto ${role === r.role ? "text-link" : "text-muted"}`} />
                <p className={`mt-1.5 text-xs font-semibold ${role === r.role ? "text-white" : "text-body"}`}>{r.label}</p>
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-6 space-y-4">
            {mode === "signup" && (
              <div>
                <label htmlFor="name" className="label">Full Name</label>
                <input
                  id="name"
                  className="input"
                  placeholder="Your full name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                />
              </div>
            )}

            <div>
              <label htmlFor="identifier" className="label">{idLabel}</label>
              <input
                id="identifier"
                type={role === "teacher" ? "text" : "email"}
                className="input"
                placeholder={idPlaceholder}
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                autoComplete={role === "teacher" ? "username" : "email"}
              />
            </div>

            {/* Student academic details — signup only */}
            {mode === "signup" && role === "student" && (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="department" className="label">Department</label>
                    <select id="department" className="input" value={department} onChange={(e) => setDepartment(e.target.value)}>
                      {DEPARTMENTS.map((d) => <option key={d}>{d}</option>)}
                    </select>
                  </div>
                  <div>
                    <label htmlFor="year" className="label">Year</label>
                    <select id="year" className="input" value={year} onChange={(e) => setYear(Number(e.target.value))}>
                      {[1, 2, 3, 4].map((y) => <option key={y} value={y}>Year {y}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="attendance" className="label">Attendance %</label>
                    <input
                      id="attendance" type="number" min={0} max={100} step="1"
                      className="input" placeholder="e.g. 87"
                      value={attendance} onChange={(e) => setAttendance(e.target.value)}
                    />
                  </div>
                  <div>
                    <label htmlFor="cgpa" className="label">CGPA</label>
                    <input
                      id="cgpa" type="number" min={0} max={10} step="0.1"
                      className="input" placeholder="e.g. 8.2"
                      value={cgpa} onChange={(e) => setCgpa(e.target.value)}
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label htmlFor="password" className="label">Password</label>
              <div className="relative">
                <input
                  id="password"
                  type={showPw ? "text" : "password"}
                  className="input !pr-11"
                  placeholder={mode === "signup" ? "At least 6 characters" : "••••••••"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  autoComplete={mode === "signup" ? "new-password" : "current-password"}
                />
                <button
                  type="button"
                  onClick={() => setShowPw(!showPw)}
                  aria-label={showPw ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted transition-colors hover:text-white"
                >
                  {showPw ? <EyeOff size={17} /> : <Eye size={17} />}
                </button>
              </div>
            </div>

            {mode === "signup" && (
              <div>
                <label htmlFor="confirm" className="label">Confirm Password</label>
                <input
                  id="confirm"
                  type={showPw ? "text" : "password"}
                  className="input"
                  placeholder="Re-enter your password"
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  autoComplete="new-password"
                />
              </div>
            )}

            <div className="flex items-center justify-between text-sm">
              <label className="flex cursor-pointer items-center gap-2 text-body">
                <input
                  type="checkbox"
                  checked={remember}
                  onChange={(e) => setRemember(e.target.checked)}
                  className="h-4 w-4 rounded border-soft bg-white/5 accent-primary"
                />
                Remember me
              </label>
            </div>

            {error && (
              <motion.p initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border border-danger/30 bg-danger/10 px-3.5 py-2.5 text-sm text-danger" role="alert">
                {error}
              </motion.p>
            )}
            {info && (
              <motion.p initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-2 rounded-xl border border-accent/30 bg-accent/10 px-3.5 py-2.5 text-sm text-accent">
                <CheckCircle2 size={15} /> {info}
              </motion.p>
            )}
            <button type="submit" className="btn-primary w-full" disabled={busy}>
              <Sparkles size={17} /> {busy ? "Please wait…" : mode === "login" ? "Login" : "Create Account"}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-muted">
            {mode === "login" ? (
              <>Don't have an account? <Link to="/signup" className="link font-semibold">Sign Up</Link></>
            ) : (
              <>Already have an account? <Link to="/login" className="link font-semibold">Login</Link></>
            )}
          </p>
        </motion.div>
      </div>
    </div>
  );
}
