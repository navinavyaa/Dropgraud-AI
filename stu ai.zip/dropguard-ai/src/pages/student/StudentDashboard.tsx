import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import {
  CalendarCheck, Brain, BookOpen, Sparkles, TrendingUp, GraduationCap,
  Clock, ClipboardList, FileCheck,
} from "lucide-react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, BarChart, Bar,
  CartesianGrid, Legend,
} from "recharts";
import { Card, StatCard, PageHeader, RiskGauge, ProgressBar, Badge, AIBadge } from "../../components/ui";
import { useAuth } from "../../context/AuthContext";
import { fetchDashboard, DashboardData, SERVER_ERROR } from "../../lib/api";

const tooltipStyle = {
  backgroundColor: "#1E293B",
  border: "1px solid rgba(255,255,255,0.1)",
  borderRadius: "12px",
  color: "#fff",
};

export default function StudentDashboard() {
  const { user } = useAuth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (user?.email) {
      fetchDashboard(user.email)
        .then(setData)
        .catch((e) => setError(e.message === "Student not found." ? e.message : SERVER_ERROR));
    }
  }, [user?.email]);

  const firstName = user?.name.split(" ")[0] ?? "there";

  if (error) {
    return (
      <div>
        <PageHeader title="Student Dashboard" subtitle={`Welcome back, ${firstName}`} icon={Sparkles} />
        <p className="rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">{error}</p>
      </div>
    );
  }

  if (!data) {
    return (
      <div>
        <PageHeader title="Student Dashboard" subtitle={`Welcome back, ${firstName} — loading your data…`} icon={Sparkles} />
        <p className="animate-pulseSoft text-sm text-muted">Loading from Excel…</p>
      </div>
    );
  }

  const s = data.student;
  const riskAdvice =
    s.riskLevel === "Low"
      ? "You're in the safe zone. Keep attendance high to stay here."
      : s.riskLevel === "Medium"
      ? "Early warning signs detected — improving attendance and CGPA will lower your risk."
      : "Your risk is high — follow the AI study plan and meet your mentor this week.";

  const hasMarks = data.subjects.some((x) => x.marks !== null);

  return (
    <div>
      <PageHeader
        title="Student Dashboard"
        subtitle={`Welcome back, ${firstName} — here's your AI-powered overview.`}
        icon={Sparkles}
        actions={<Link to="/student/resume" className="btn-primary !py-2 text-sm">Build Resume</Link>}
      />

      {/* Top stats — all values from students.xlsx */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard icon={CalendarCheck} label="Attendance" value={`${s.attendance}%`} sub={`${s.department} · Year ${s.year}`} color="#06B6D4" />
        <StatCard icon={GraduationCap} label="CGPA" value={String(s.cgpa)} sub="From your registration" color="#A855F7" delay={0.08} />
        <StatCard icon={ClipboardList} label="Quiz Average" value={s.quizAverage !== null ? `${s.quizAverage}%` : "—"} sub={s.quizAverage !== null ? "From your records" : "Not recorded yet"} color="#F59E0B" delay={0.16} />
        <StatCard icon={FileCheck} label="Semester Marks" value={s.semMarks !== null ? `${s.semMarks}%` : "—"} sub={s.semMarks !== null ? "From your records" : "Not recorded yet"} color="#22C55E" delay={0.24} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Risk score */}
        <Card className="flex flex-col items-center justify-center text-center">
          <div className="mb-2 flex items-center gap-2">
            <h3 className="font-semibold text-white">Dropout Risk Score</h3>
            <AIBadge text="AI" />
          </div>
          <RiskGauge score={s.riskScore} level={s.riskLevel} />
          <p className="mt-3 text-sm text-body">{riskAdvice}</p>
          <p className="mt-1 text-xs text-muted">Calculated from your attendance ({s.attendance}%) and CGPA ({s.cgpa})</p>
        </Card>

        {/* Attendance trend — Att1..Att6 columns */}
        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-semibold text-white">Attendance Trend</h3>
            <Badge color="#06B6D4">vs Class Average</Badge>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={data.attendanceTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
              <XAxis dataKey="month" stroke="#94A3B8" fontSize={12} />
              <YAxis stroke="#94A3B8" fontSize={12} domain={[40, 100]} />
              <Tooltip contentStyle={tooltipStyle} />
              <Legend wrapperStyle={{ fontSize: 12 }} />
              <Line type="monotone" dataKey="attendance" name="You" stroke="#7C3AED" strokeWidth={3} dot={{ fill: "#7C3AED" }} />
              <Line type="monotone" dataKey="classAvg" name="Class Avg" stroke="#06B6D4" strokeWidth={2} strokeDasharray="6 4" dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Subject performance — marks columns */}
        <Card className="lg:col-span-2">
          <h3 className="mb-4 font-semibold text-white">Subject Performance</h3>
          {hasMarks ? (
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={data.subjects}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis dataKey="subject" stroke="#94A3B8" fontSize={12} />
                <YAxis stroke="#94A3B8" fontSize={12} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
                <Legend wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="marks" name="Your Marks" fill="#7C3AED" radius={[6, 6, 0, 0]} />
                <Bar dataKey="classAvg" name="Class Avg" fill="#06B6D4" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="py-12 text-center text-sm text-muted">
              No subject marks recorded yet. Once your marks are added to students.xlsx, they'll appear here automatically.
            </p>
          )}
        </Card>

        {/* AI suggestions — derived server-side from your Excel record */}
        <Card>
          <div className="mb-4 flex items-center gap-2">
            <Brain size={18} className="text-link" />
            <h3 className="font-semibold text-white">AI Suggestions</h3>
          </div>
          <div className="space-y-3">
            {data.suggestions.map((sug, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="rounded-xl border border-soft bg-white/5 p-3"
              >
                <Badge color={sug.tag === "Attendance" ? "#F59E0B" : sug.tag === "Risk" ? "#EF4444" : sug.tag === "Schedule" ? "#06B6D4" : "#A855F7"}>{sug.tag}</Badge>
                <p className="mt-1.5 text-sm text-body">{sug.text}</p>
              </motion.div>
            ))}
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Assessment overview — QuizAverage / SemMarks columns */}
        <Card className="lg:col-span-2">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-semibold text-white">Assessment Overview</h3>
            <Badge color="#22C55E"><TrendingUp size={12} /> From your records</Badge>
          </div>
          <div className="space-y-5">
            {[
              { label: "Quiz Average", value: s.quizAverage, color: "#A855F7" },
              { label: "Semester Marks", value: s.semMarks, color: "#06B6D4" },
              { label: "Attendance", value: s.attendance, color: "#F59E0B" },
              { label: "CGPA (×10)", value: Math.round(s.cgpa * 10), color: "#22C55E" },
            ].map((m) => (
              <div key={m.label}>
                <div className="mb-1 flex justify-between text-sm">
                  <span className="text-white">{m.label}</span>
                  <span className="font-semibold" style={{ color: m.color }}>{m.value !== null ? `${m.value}%` : "Not recorded"}</span>
                </div>
                <ProgressBar value={m.value ?? 0} color={m.color} />
              </div>
            ))}
          </div>
        </Card>

        {/* Study schedule — events.xlsx */}
        <Card>
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-semibold text-white">Study Schedule</h3>
            <Badge color="#06B6D4">From events.xlsx</Badge>
          </div>
          <div className="space-y-2.5">
            {data.events.slice(0, 5).map((e, i) => (
              <div key={i} className="flex items-center gap-3 rounded-xl bg-white/5 p-3">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg" style={{ backgroundColor: `${e.color}22`, color: e.color }}>
                  <Clock size={16} />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-white">{e.title}</p>
                  <p className="text-xs text-muted">{e.type}</p>
                </div>
                <span className="text-xs font-semibold" style={{ color: e.color }}>{e.date}</span>
              </div>
            ))}
            {data.events.length === 0 && <p className="py-4 text-center text-sm text-muted">No upcoming events in events.xlsx.</p>}
          </div>
        </Card>
      </div>

      {/* Quick links — navigation only, no fabricated numbers */}
      <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-4">
        {[
          { to: "/student/resume", label: "AI Resume Builder", icon: Sparkles, desc: "Build & score your resume", color: "#7C3AED" },
          { to: "/student/interview", label: "Mock Interview", icon: Brain, desc: "120 questions, AI scoring", color: "#06B6D4" },
          { to: "/student/chat", label: "AI Chat Assistant", icon: BookOpen, desc: "Ask about your record", color: "#22C55E" },
          { to: "/student/placement", label: "Placement Readiness", icon: TrendingUp, desc: "Your weighted score", color: "#F59E0B" },
        ].map((q, i) => (
          <motion.div key={q.to} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 + i * 0.08 }}>
            <Link to={q.to} className="glass-card glass-card-hover block p-4">
              <q.icon size={20} style={{ color: q.color }} />
              <p className="mt-2 text-sm font-semibold text-white">{q.label}</p>
              <p className="text-xs text-muted">{q.desc}</p>
            </Link>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
