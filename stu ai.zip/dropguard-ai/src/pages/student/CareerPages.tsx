import { useMemo } from "react";
import { motion } from "framer-motion";
import { Target, TrendingUp, GraduationCap, Award, Briefcase, BookOpen, Sparkles } from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, Tooltip } from "recharts";
import { Card, PageHeader, ProgressBar, Badge, AIBadge, RiskGauge } from "../../components/ui";
import { useAuth } from "../../context/AuthContext";
import { useToast } from "../../hooks/useToast";

const tooltipStyle = {
  backgroundColor: "#1E293B", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "12px", color: "#fff",
};

const clamp = (v: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, v));

function useProfile() {
  const { user } = useAuth();
  const marks = user?.marks ?? {};
  const m = (s: string) => (typeof marks[s] === "number" ? (marks[s] as number) : null);
  const cgpa = user?.cgpa ?? 0;
  const fallback = cgpa * 10;
  const val = (...subs: string[]) => {
    const known = subs.map(m).filter((x): x is number => x !== null);
    return known.length ? known.reduce((a, b) => a + b, 0) / known.length : fallback;
  };
  return { user, m, cgpa, val, attendance: user?.attendance ?? 0, quiz: user?.quizAverage ?? null, streak: user?.studyStreak ?? 0 };
}

/* ---------------- Placement Readiness — weighted score from your record ---------------- */

export function PlacementReadiness() {
  const { user, m, quiz, streak } = useProfile();
  const [toastEl, toast] = useToast();

  const factors = useMemo(() => {
    const marksKnown = ["Maths", "DSA", "DBMS", "OS", "Networks", "AIML"].map(m).filter((x): x is number => x !== null);
    const subjectAvg = marksKnown.length ? marksKnown.reduce((a, b) => a + b, 0) / marksKnown.length : null;
    return [
      { label: "Attendance", value: user?.attendance ?? 0, weight: 0.2 },
      { label: "CGPA", value: Math.round((user?.cgpa ?? 0) * 10), weight: 0.25 },
      { label: "Quiz Performance", value: quiz, weight: 0.15 },
      { label: "Coding (DSA)", value: m("DSA"), weight: 0.15 },
      { label: "Subject Average", value: subjectAvg !== null ? Math.round(subjectAvg) : null, weight: 0.15 },
      { label: "Consistency (streak)", value: clamp(streak * 4, 0, 100), weight: 0.1 },
    ];
  }, [user, quiz, streak]); // eslint-disable-line react-hooks/exhaustive-deps

  const known = factors.filter((f) => f.value !== null) as { label: string; value: number; weight: number }[];
  const totalWeight = known.reduce((a, f) => a + f.weight, 0);
  const overall = totalWeight ? Math.round(known.reduce((a, f) => a + f.value * f.weight, 0) / totalWeight) : 0;
  const verdict = overall >= 90 ? "Excellent" : overall >= 70 ? "Good" : overall >= 50 ? "Average" : "Needs Improvement";
  const verdictColor = overall >= 90 ? "#22C55E" : overall >= 70 ? "#22C55E" : overall >= 50 ? "#F59E0B" : "#EF4444";

  const weakest = [...known].sort((a, b) => a.value - b.value)[0];

  return (
    <div>
      {toastEl}
      <PageHeader
        title="AI Placement Readiness"
        subtitle="A weighted score computed live from your Excel record."
        icon={GraduationCap}
        actions={
          <button className="btn-primary !py-2 text-sm" onClick={() => toast("Readiness report queued (demo)")}>
            Download Report
          </button>
        }
      />
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="flex flex-col items-center justify-center text-center">
          <h3 className="mb-2 font-semibold text-white">Overall Readiness</h3>
          <div className="relative inline-flex items-center justify-center" style={{ width: 150, height: 150 }}>
            <svg width={150} height={150} className="-rotate-90">
              <circle cx={75} cy={75} r={66} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={12} />
              <circle
                cx={75} cy={75} r={66} fill="none" stroke={verdictColor} strokeWidth={12} strokeLinecap="round"
                strokeDasharray={2 * Math.PI * 66}
                strokeDashoffset={2 * Math.PI * 66 * (1 - overall / 100)}
                style={{ filter: `drop-shadow(0 0 8px ${verdictColor}88)` }}
              />
            </svg>
            <div className="absolute text-center">
              <p className="text-3xl font-bold text-white">{overall}</p>
              <p className="text-xs font-semibold" style={{ color: verdictColor }}>{verdict}</p>
            </div>
          </div>
          <p className="mt-2 text-xs text-muted">Excellent ≥ 90 · Good 70–89 · Average 50–69 · Needs Improvement &lt; 50</p>
        </Card>
        <Card className="lg:col-span-2">
          <h3 className="mb-4 font-semibold text-white">Factor Breakdown</h3>
          <div className="space-y-3.5">
            {factors.map((f) => {
              const color = f.value === null ? "#94A3B8" : f.value >= 85 ? "#22C55E" : f.value >= 70 ? "#F59E0B" : "#EF4444";
              return (
                <div key={f.label}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="text-white">{f.label} <span className="text-xs text-muted">({Math.round(f.weight * 100)}%)</span></span>
                    <span style={{ color }} className="font-semibold">{f.value !== null ? `${f.value}%` : "Not recorded"}</span>
                  </div>
                  <ProgressBar value={f.value ?? 0} color={color} />
                </div>
              );
            })}
          </div>
        </Card>
      </div>
      <Card className="mt-6">
        <div className="mb-3 flex items-center gap-2">
          <Sparkles size={17} className="text-link" />
          <h3 className="font-semibold text-white">AI Action Plan</h3>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {weakest && (
            <div className="rounded-xl border border-primary/20 bg-primary/10 p-4 text-sm text-body">
              Your weakest factor is <span className="font-semibold text-white">{weakest.label} ({weakest.value}%)</span> — improving it has the biggest impact on your readiness score.
            </div>
          )}
          <div className="rounded-xl border border-primary/20 bg-primary/10 p-4 text-sm text-body">
            {overall >= 70
              ? "You're close to placement-ready. Keep your streak alive and maintain attendance to protect the score."
              : "Focus on consistent daily study sessions — the streak factor compounds with quiz performance."}
          </div>
          <div className="rounded-xl border border-primary/20 bg-primary/10 p-4 text-sm text-body">
            Practice with the Mock Interview module — 120 questions across Technical, HR, Behavioral, and Role Specific rounds.
          </div>
        </div>
      </Card>
    </div>
  );
}
