import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Mic, Bot, Send, Lightbulb, Sparkles, Shuffle } from "lucide-react";
import { Card, PageHeader, ProgressBar, Badge, AIBadge } from "../../components/ui";
import { useAuth } from "../../context/AuthContext";

/* ---------------- Mock Interview — 30 questions per mode ---------------- */

type InterviewMode = "Technical" | "HR" | "Behavioral" | "Role Specific";

const questionBank: Record<InterviewMode, string[]> = {
  Technical: [
    "Explain the difference between a list and a tuple in Python.",
    "How does an index speed up a SQL query, and when can it hurt performance?",
    "Walk me through how you'd detect overfitting in an ML model.",
    "What is the difference between a process and a thread?",
    "Explain the four pillars of object-oriented programming with examples.",
    "What happens when you type a URL into a browser and press Enter?",
    "Explain the difference between TCP and UDP. When would you choose each?",
    "What is a deadlock? Describe the four conditions required for one.",
    "Explain normalization. Why might you deliberately denormalize a table?",
    "What is the time complexity of quicksort in the best, average, and worst cases?",
    "How does a hash map work internally? What happens on a collision?",
    "Explain the difference between stack and heap memory.",
    "What are ACID properties in a database transaction?",
    "Explain virtual memory and paging in an operating system.",
    "What is the difference between an abstract class and an interface?",
    "How would you find the middle element of a linked list in one pass?",
    "Explain REST. What makes an API RESTful?",
    "What is the difference between SQL JOIN types: INNER, LEFT, RIGHT, FULL?",
    "Explain how garbage collection works in a managed language.",
    "What is a race condition? How do you prevent one?",
    "Explain the bias–variance tradeoff in machine learning.",
    "What is the difference between HTTP and HTTPS? How does TLS work at a high level?",
    "How does DNS resolution work?",
    "Explain recursion and give a case where iteration is clearly better.",
    "What are database transactions and isolation levels?",
    "Explain the difference between compile-time and runtime errors with examples.",
    "What is Big-O notation? Why do we ignore constants?",
    "How would you design a URL shortener? Outline the key components.",
    "Explain caching. Where can caches live in a web application stack?",
    "What is the CAP theorem, and what does it mean for distributed systems?",
  ],
  HR: [
    "Tell me about yourself in under two minutes.",
    "Why do you want to join our company?",
    "Where do you see yourself in five years?",
    "What are your greatest strengths, with examples?",
    "What is your biggest weakness, and what are you doing about it?",
    "Why should we hire you over other candidates?",
    "What do you know about our company and products?",
    "What are your salary expectations, and how did you arrive at them?",
    "Are you willing to relocate or work in shifts?",
    "How do you handle criticism of your work?",
    "Describe your ideal work environment.",
    "What motivates you to do your best work?",
    "How do you manage stress and pressure?",
    "What would your professors or teammates say about you?",
    "Why did you choose your branch of engineering?",
    "What do you do outside of academics?",
    "Have you led any team or club? What did you learn?",
    "What was your biggest failure, and what did it teach you?",
    "How do you keep your skills up to date?",
    "If you get a better offer after joining us, what would you do?",
    "What questions do you have for us?",
    "Describe a time you balanced multiple priorities at once.",
    "What does success mean to you?",
    "How soon can you join if selected?",
    "Is there a gap or backlog in your academics? Walk me through it.",
    "Which of our company values resonates most with you and why?",
    "What role do you usually play in a team?",
    "Tell me about a professional or academic achievement you're proud of.",
    "How do you react when you don't know the answer to something?",
    "Why are you interested in this specific role rather than similar ones?",
  ],
  Behavioral: [
    "Describe a time you had a conflict in a team project. How did you resolve it?",
    "Tell me about a deadline you almost missed and what you did.",
    "Give an example of when you took initiative without being asked.",
    "Describe a situation where you had to learn something completely new, fast.",
    "Tell me about a time you disagreed with a teammate's approach.",
    "Describe a time you received harsh feedback. How did you respond?",
    "Tell me about a time you failed publicly. What happened next?",
    "Give an example of a goal you set and how you achieved it.",
    "Describe a time you helped a struggling teammate.",
    "Tell me about a time you had to convince others of your idea.",
    "Describe the most difficult decision you've made in the last year.",
    "Tell me about a time you had too many tasks and too little time.",
    "Give an example of when you went above and beyond what was required.",
    "Describe a time you made a mistake that affected others. How did you handle it?",
    "Tell me about a time you worked with someone very different from you.",
    "Describe a situation where you had incomplete information but had to act.",
    "Tell me about a time you improved a process or made something more efficient.",
    "Give an example of how you handled an unfair situation.",
    "Describe a time you had to say no to someone senior.",
    "Tell me about the hardest bug or problem you've ever debugged.",
    "Describe a time your first plan failed and you had to adapt.",
    "Tell me about a time you motivated a demotivated team.",
    "Give an example of when attention to detail saved you (or the lack of it cost you).",
    "Describe a time you had to deliver bad news to a team or stakeholder.",
    "Tell me about a time you balanced quality against a deadline.",
    "Describe a project you're most proud of and your exact contribution.",
    "Tell me about a time you sought help. How did you decide when to ask?",
    "Give an example of handling two commitments that clashed.",
    "Describe a time you turned a critic into a supporter.",
    "Tell me about a risk you took that didn't pay off — and one that did.",
  ],
  "Role Specific": [
    "As a data analyst, how would you present a confusing dataset to non-technical stakeholders?",
    "Which chart would you pick to show month-over-month churn, and why?",
    "How would you validate a dashboard metric a manager says 'looks wrong'?",
    "A/B test results are inconclusive. What do you check before extending the test?",
    "How would you handle missing values in a dataset before modeling?",
    "Explain how you'd detect and treat outliers in sales data.",
    "Walk me through cleaning a messy Excel export with merged cells and mixed types.",
    "What KPIs would you track for a student-retention product like DropGuard?",
    "How would you explain p-values to someone with no statistics background?",
    "Describe how you'd build a churn-prediction model end to end.",
    "SQL: how would you find the second-highest salary per department?",
    "How do you decide between a bar chart, line chart, and heatmap?",
    "A stakeholder wants 'all the data' in one dashboard. How do you respond?",
    "How would you measure whether a new feature actually improved engagement?",
    "Explain the difference between correlation and causation with a business example.",
    "Your model has 95% accuracy on an imbalanced dataset. Why might that be misleading?",
    "How would you forecast next semester's dropout rate from historical data?",
    "What steps do you take to make sure an analysis is reproducible?",
    "Describe a time when data contradicted a leader's intuition. What would you do?",
    "How do you prioritize ad-hoc requests against long-term analytics projects?",
    "Explain feature engineering with two concrete examples.",
    "How would you design an early-warning alert so it isn't ignored as noise?",
    "What's your process for validating data coming from a new source?",
    "How would you quantify the business impact of reducing dropout by 2%?",
    "Which metrics would you show a teacher vs a principal, and why the difference?",
    "How do you communicate uncertainty in a prediction to decision makers?",
    "Describe how you would document a data pipeline for a teammate.",
    "A report takes 4 hours to refresh. How do you diagnose and speed it up?",
    "When is a simple average misleading? Give two examples.",
    "How would you decide whether to build a dashboard or send a weekly email report?",
  ],
};

export function MockInterview() {
  const [mode, setMode] = useState<InterviewMode>("Technical");
  const [qIndex, setQIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [result, setResult] = useState<null | { confidence: number; communication: number; technical: number; feedback: string[] }>(null);

  const questions = questionBank[mode];

  const evaluate = () => {
    const len = answer.trim().length;
    const hasNumbers = /\d/.test(answer);
    const hasStructure = /first|then|finally|because|for example|e\.g\./i.test(answer);
    const base = Math.min(90, 40 + len / 8);
    setResult({
      confidence: Math.round(Math.min(95, base + (hasStructure ? 8 : 0))),
      communication: Math.round(Math.min(95, base + (hasStructure ? 10 : -5))),
      technical: Math.round(Math.min(95, base + (hasNumbers ? 8 : 0) + (mode === "Technical" ? 4 : 0))),
      feedback: [
        len < 120 ? "Your answer is short — aim for 60–90 seconds of speaking (150+ words)." : "Good answer length — detailed but not rambling.",
        hasStructure ? "Nice structure — you used connectives to guide the listener." : "Add structure: 'First… then… finally…' or the STAR method.",
        hasNumbers ? "Great use of concrete numbers — recruiters remember specifics." : "Quantify where possible: metrics and results make answers memorable.",
      ],
    });
  };

  const next = (i?: number) => {
    setQIndex(i ?? (qIndex + 1) % questions.length);
    setAnswer("");
    setResult(null);
  };

  return (
    <div>
      <PageHeader title="AI Mock Interview" subtitle={`${questions.length} questions per mode — practice with instant AI scoring.`} icon={Mic} actions={<AIBadge text="Interview Coach" />} />
      <div className="mb-5 flex flex-wrap gap-2">
        {(Object.keys(questionBank) as InterviewMode[]).map((m) => (
          <button
            key={m}
            onClick={() => { setMode(m); setQIndex(0); setAnswer(""); setResult(null); }}
            className={`rounded-xl px-4 py-2 text-sm font-semibold transition-all ${mode === m ? "bg-gradient-to-r from-primary to-secondary text-white shadow-glow" : "bg-white/5 text-body hover:bg-white/10"}`}
          >
            {m} ({questionBank[m].length})
          </button>
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card hover={false}>
          <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
            <Badge color="#7C3AED">Question {qIndex + 1} of {questions.length}</Badge>
            <div className="flex gap-3">
              <button className="link text-xs font-semibold" onClick={() => next(Math.floor(Math.random() * questions.length))}>
                <Shuffle size={12} className="inline" /> Random
              </button>
              <button className="link text-xs font-semibold" onClick={() => next()}>Next question →</button>
            </div>
          </div>
          <p className="text-lg font-semibold text-white">{questions[qIndex]}</p>
          <textarea
            className="input mt-4 min-h-[160px]"
            placeholder="Type your answer as you would say it aloud…"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
          />
          <button className="btn-primary mt-4" onClick={evaluate} disabled={!answer.trim()}>
            <Sparkles size={16} /> Evaluate Answer
          </button>
          {/* Question navigator */}
          <div className="mt-5 flex flex-wrap gap-1.5" aria-label="Question navigator">
            {questions.map((_, i) => (
              <button
                key={i}
                onClick={() => next(i)}
                aria-label={`Go to question ${i + 1}`}
                className={`h-7 w-7 rounded-lg text-[11px] font-semibold transition-all ${i === qIndex ? "bg-gradient-to-r from-primary to-secondary text-white" : "bg-white/5 text-muted hover:bg-white/10 hover:text-white"}`}
              >
                {i + 1}
              </button>
            ))}
          </div>
        </Card>
        <Card hover={false}>
          <h3 className="mb-4 font-semibold text-white">AI Evaluation</h3>
          {!result ? (
            <p className="text-sm text-muted">Answer the question and hit Evaluate — you'll get Confidence, Communication, and Technical scores with improvement tips.</p>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <div className="space-y-4">
                {[
                  { label: "Confidence", value: result.confidence, color: "#7C3AED" },
                  { label: "Communication", value: result.communication, color: "#06B6D4" },
                  { label: "Technical Accuracy", value: result.technical, color: "#22C55E" },
                ].map((s) => (
                  <div key={s.label}>
                    <div className="mb-1 flex justify-between text-sm">
                      <span className="text-white">{s.label}</span>
                      <span className="font-semibold" style={{ color: s.color }}>{s.value}%</span>
                    </div>
                    <ProgressBar value={s.value} color={s.color} />
                  </div>
                ))}
              </div>
              <div className="mt-5 space-y-2">
                {result.feedback.map((f, i) => (
                  <div key={i} className="flex items-start gap-2 rounded-lg bg-white/5 p-3 text-sm text-body">
                    <Lightbulb size={15} className="mt-0.5 shrink-0 text-warning" /> {f}
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </Card>
      </div>
    </div>
  );
}

/* ---------------- AI Chatbot — answers use your live Excel record ---------------- */

interface ChatMsg { from: "user" | "ai"; text: string }

export function Chatbot() {
  const { user } = useAuth();
  const marks = user?.marks ?? {};
  const knownMarks = Object.entries(marks).filter(([, v]) => typeof v === "number") as [string, number][];
  const weakest = knownMarks.length ? knownMarks.reduce((a, b) => (a[1] <= b[1] ? a : b)) : null;
  const strongest = knownMarks.length ? knownMarks.reduce((a, b) => (a[1] >= b[1] ? a : b)) : null;
  const marksLine = knownMarks.length
    ? knownMarks.map(([s, v]) => `${s} ${v}%`).join(", ")
    : "not recorded yet — once added to students.xlsx they'll appear across the app";

  const cannedReplies: [RegExp, string][] = [
    [/attendance/i, `Your overall attendance is ${user?.attendance ?? "—"}%. ${(user?.attendance ?? 100) < 75 ? "That's below the 75% requirement — attend upcoming classes consistently to recover." : "You're above the 75% requirement — keep it up!"}`],
    [/risk|dropout/i, `Your dropout risk score is ${user?.riskScore ?? "—"} (${user?.riskLevel ?? "—"}), calculated from attendance (${user?.attendance}%) and CGPA (${user?.cgpa}). ${user?.riskLevel === "Low" ? "You're in the safe zone!" : "Improving attendance and CGPA will lower it."}`],
    [/cgpa|gpa/i, `Your CGPA is ${user?.cgpa ?? "—"}. It carries a 25% weight in placement readiness and directly lowers your risk score — every 0.1 improvement reduces risk by ~0.45 points.`],
    [/marks|subject|score/i, `Your subject marks: ${marksLine}.${weakest ? ` Weakest: ${weakest[0]} (${weakest[1]}%).` : ""}${strongest ? ` Strongest: ${strongest[0]} (${strongest[1]}%).` : ""}`],
    [/weak/i, weakest ? `Your weakest subject is ${weakest[0]} at ${weakest[1]}% — focus revision there first; it's also dragging your placement readiness down.` : "No subject marks recorded yet, so I can't identify a weakest subject. Ask your teacher to update students.xlsx."],
    [/strong|best subject/i, strongest ? `Your strongest subject is ${strongest[0]} at ${strongest[1]}% — great foundation. Consider projects or certifications that build on it.` : "No subject marks recorded yet."],
    [/quiz/i, `Your quiz average is ${user?.quizAverage ?? "not recorded"}${user?.quizAverage != null ? "%" : ""}. Quizzes weigh 15% in your placement readiness score.`],
    [/sem|semester marks/i, `Your semester marks: ${user?.semMarks ?? "not recorded"}${user?.semMarks != null ? "%" : ""}.`],
    [/streak/i, `Your study streak is ${user?.studyStreak ?? 0} days. Streaks build consistency — the readiness score counts it under the consistency factor.`],
    [/xp|rank|leader/i, `You have ${user?.xp?.toLocaleString() ?? 0} XP. XP and streaks live in students.xlsx — they update as your record changes.`],
    [/resume|ats/i, "Open the AI Resume Builder — it scores your resume live (0–100 ATS) as you fill each section, and the AI can generate your career objective and improve project descriptions."],
    [/placement|readiness/i, `Your Placement Readiness page computes a weighted score from attendance (${user?.attendance}%), CGPA (${user?.cgpa}), quiz average, DSA marks, subject average, and your streak. Check it for the factor-by-factor breakdown.`],
    [/interview/i, "The Mock Interview module has 30 questions in each of 4 modes — Technical, HR, Behavioral, and Role Specific — with instant AI scoring on confidence, communication, and technical accuracy."],
    [/skill|gap/i, weakest ? `Based on your marks, strengthen ${weakest[0]} first (${weakest[1]}%) — it's furthest from placement target levels.` : "Once your subject marks are recorded, I can tell you exactly which skills to strengthen first."],
    [/assignment/i, "Check the Assignments page — you'll see every assignment from your teachers with due dates, submit PDF/Word files, and view your marks and feedback once evaluated."],
    [/message|teacher/i, "If a teacher sends you a message, you'll see a high-priority alert as soon as you log in. Check the bell icon for other notifications."],
    [/department|year/i, `You're in ${user?.department ?? "—"}, Year ${user?.year ?? "—"}, registered as ${user?.email ?? "—"}.`],
    [/hello|hi\b|hey/i, `Hi ${user?.name.split(" ")[0] ?? "there"}! Ask me about your attendance, risk score, marks, CGPA, streak, placement readiness, resume, or interviews.`],
    [/thank/i, "You're welcome! Keep that streak going — consistency is the strongest dropout-risk reducer in the model. 🎓"],
    [/help|what can you/i, "I can answer questions about: attendance, dropout risk, CGPA, subject marks, weakest/strongest subject, quiz average, semester marks, study streak, XP, resume & ATS, placement readiness, mock interviews, skill gaps, assignments, and teacher messages."],
  ];

  const [msgs, setMsgs] = useState<ChatMsg[]>([
    { from: "ai", text: `Hi ${user?.name.split(" ")[0] ?? "there"}! I'm your DropGuard AI assistant. Ask me about your attendance, risk score, marks, placement readiness, resume, interviews and more. Type "help" to see everything I can do. 🎓` },
  ]);
  const [input, setInput] = useState("");
  const [typing, setTyping] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs, typing]);

  const send = (preset?: string) => {
    const text = (preset ?? input).trim();
    if (!text) return;
    setMsgs((m) => [...m, { from: "user", text }]);
    setInput("");
    setTyping(true);
    const reply =
      cannedReplies.find(([re]) => re.test(text))?.[1] ??
      'I can help with your academics and placement prep. Try: "How is my attendance?", "What are my marks?", "What\'s my weakest subject?", "Am I placement ready?" — or type "help".';
    setTimeout(() => {
      setTyping(false);
      setMsgs((m) => [...m, { from: "ai", text: reply }]);
    }, 700);
  };

  const quickQuestions = [
    "How is my attendance?",
    "What's my risk score?",
    "What are my marks?",
    "What's my weakest subject?",
    "What's my CGPA?",
    "Am I placement ready?",
    "Resume tips",
    "How do mock interviews work?",
    "What's my streak?",
    "help",
  ];

  return (
    <div>
      <PageHeader title="AI Chat Assistant" subtitle="Your 24×7 academic and career companion — answers use your live record." icon={Bot} actions={<AIBadge text="Online" />} />
      <Card hover={false} className="flex h-[65vh] flex-col !p-0">
        <div className="flex-1 space-y-4 overflow-y-auto p-5">
          {msgs.map((m, i) => (
            <motion.div key={i} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${m.from === "user" ? "bg-gradient-to-r from-primary to-secondary text-white" : "border border-soft bg-white/5 text-body"}`}>
                {m.text}
              </div>
            </motion.div>
          ))}
          {typing && (
            <div className="flex justify-start">
              <div className="rounded-2xl border border-soft bg-white/5 px-4 py-3 text-sm text-muted">
                <span className="animate-pulseSoft">DropGuard AI is typing…</span>
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>
        <div className="border-t border-soft p-4">
          <div className="mb-3 flex flex-wrap gap-2">
            {quickQuestions.map((q) => (
              <button key={q} onClick={() => send(q)} className="badge bg-white/5 text-body hover:bg-primary/20 hover:text-link">{q}</button>
            ))}
          </div>
          <div className="flex gap-2">
            <input
              className="input"
              placeholder="Ask me anything…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && send()}
              aria-label="Chat message"
            />
            <button className="btn-primary !px-4" onClick={() => send()} aria-label="Send message">
              <Send size={17} />
            </button>
          </div>
        </div>
      </Card>
    </div>
  );
}
