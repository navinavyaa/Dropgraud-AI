import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { ClipboardList, Paperclip, Upload, CheckCircle2, Clock, MessageSquareText, RefreshCw } from "lucide-react";
import { Card, PageHeader, Badge } from "../../components/ui";
import { useToast } from "../../hooks/useToast";
import { useAuth } from "../../context/AuthContext";
import { fetchAssignments, submitAssignment, fileToBase64, statusColor, Assignment, SERVER_ERROR } from "../../lib/api";

const MAX_MB = 10;

export default function Assignments() {
  const { user } = useAuth();
  const [assignments, setAssignments] = useState<Assignment[] | null>(null);
  const [error, setError] = useState("");
  const [uploading, setUploading] = useState<string | null>(null);
  const [toastEl, toast] = useToast();
  const fileInputs = useRef<Record<string, HTMLInputElement | null>>({});

  const load = () => {
    if (!user?.email) return;
    fetchAssignments(user.email)
      .then((a) => { setAssignments(a); setError(""); })
      .catch(() => setError(SERVER_ERROR));
  };

  useEffect(load, [user?.email]); // eslint-disable-line react-hooks/exhaustive-deps

  const upload = async (a: Assignment, file: File | undefined) => {
    if (!file || !user?.email) return;
    if (!/\.(pdf|doc|docx)$/i.test(file.name)) {
      toast("Only PDF and Word documents (.pdf, .doc, .docx) are accepted");
      return;
    }
    if (file.size > MAX_MB * 1024 * 1024) {
      toast(`File is too large — maximum ${MAX_MB} MB`);
      return;
    }
    setUploading(a.id);
    try {
      const data = await fileToBase64(file);
      const res = await submitAssignment(a.id, user.email, { name: file.name, data });
      if (!res.ok) toast(res.error ?? "Submission failed");
      else {
        toast(`"${file.name}" submitted for ${a.title}`);
        load();
      }
    } catch {
      toast("Submission failed — is the server running?");
    } finally {
      setUploading(null);
    }
  };

  const canSubmit = (a: Assignment) => !["Approved", "Graded"].includes(a.status ?? "");

  return (
    <div>
      {toastEl}
      <PageHeader
        title="Assignments"
        subtitle="Assignments published by your teachers — submit PDF or Word documents."
        icon={ClipboardList}
        actions={
          <button className="btn-ghost !py-2 text-sm" onClick={load}>
            <RefreshCw size={15} /> Refresh
          </button>
        }
      />

      {error && <p className="mb-6 rounded-xl border border-danger/30 bg-danger/10 px-4 py-3 text-sm text-danger" role="alert">{error}</p>}
      {!assignments && !error && <p className="animate-pulseSoft text-sm text-muted">Loading assignments…</p>}
      {assignments && assignments.length === 0 && (
        <Card hover={false}><p className="py-8 text-center text-sm text-muted">No assignments published yet. Check back later.</p></Card>
      )}

      <div className="space-y-5">
        {assignments?.map((a, i) => (
          <motion.div key={a.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.07 }}>
            <Card hover={false}>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-lg font-bold text-white">{a.title}</h3>
                    {a.subject && <Badge color="#06B6D4">{a.subject}</Badge>}
                    <Badge color={statusColor(a.status ?? "Not Started")}>{a.status}</Badge>
                  </div>
                  <p className="mt-1 text-xs text-muted">By {a.createdBy}</p>
                </div>
                <div className="text-right">
                  <p className={`flex items-center gap-1.5 text-sm font-semibold ${a.overdue ? "text-danger" : "text-warning"}`}>
                    <Clock size={14} /> Due {a.dueLabel}{a.overdue ? " (overdue)" : ""}
                  </p>
                  {a.submittedAt && <p className="mt-0.5 text-xs text-muted">Submitted {a.submittedAt}</p>}
                </div>
              </div>

              <p className="mt-3 text-sm leading-relaxed text-body">{a.description}</p>

              {a.attachmentUrl && (
                <a href={a.attachmentUrl} target="_blank" rel="noreferrer" className="mt-3 inline-flex items-center gap-1.5 rounded-lg bg-white/5 px-3 py-1.5 text-xs font-medium text-link hover:bg-white/10">
                  <Paperclip size={13} /> {a.attachment?.replace(/^\d+_/, "")}
                </a>
              )}

              {/* Marks + feedback once evaluated */}
              {(a.marks !== null && a.marks !== undefined) || a.feedback ? (
                <div className={`mt-4 rounded-xl border p-4 ${a.status === "Rejected" ? "border-danger/30 bg-danger/10" : "border-success/30 bg-success/10"}`}>
                  <div className="flex flex-wrap items-center gap-4">
                    {a.marks !== null && a.marks !== undefined && (
                      <p className="text-sm font-bold text-white">Marks: <span className={a.status === "Rejected" ? "text-danger" : "text-success"}>{a.marks}</span></p>
                    )}
                    {a.feedback && (
                      <p className="flex items-start gap-1.5 text-sm text-body"><MessageSquareText size={15} className="mt-0.5 shrink-0 text-link" /> {a.feedback}</p>
                    )}
                  </div>
                </div>
              ) : null}

              {/* Submission controls */}
              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-soft pt-4">
                {a.fileUrl && (
                  <a href={a.fileUrl} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1.5 text-xs text-body hover:text-white">
                    <CheckCircle2 size={14} className="text-success" /> Your submission: <span className="text-link">{a.fileName}</span>
                  </a>
                )}
                {canSubmit(a) ? (
                  <>
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx"
                      className="hidden"
                      ref={(el) => (fileInputs.current[a.id] = el)}
                      onChange={(e) => { upload(a, e.target.files?.[0]); e.target.value = ""; }}
                    />
                    <button
                      className="btn-primary !px-4 !py-2 text-xs"
                      disabled={uploading === a.id}
                      onClick={() => fileInputs.current[a.id]?.click()}
                    >
                      <Upload size={14} /> {uploading === a.id ? "Uploading…" : a.fileUrl ? "Resubmit" : "Submit Assignment"}
                    </button>
                    <span className="text-[11px] text-muted">PDF or Word, max {MAX_MB} MB</span>
                  </>
                ) : (
                  <Badge color="#22C55E">Finalized — no further submissions needed</Badge>
                )}
              </div>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
