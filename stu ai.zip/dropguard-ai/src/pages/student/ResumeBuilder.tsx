import { useEffect, useMemo, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileText, Sparkles, ChevronLeft, ChevronRight, Download, Printer, CloudUpload,
  CheckCircle2, User, GraduationCap, Wrench, FolderKanban, Award, Target, Wand2,
} from "lucide-react";
import { jsPDF } from "jspdf";
import { Card, PageHeader, ProgressBar, Badge, AIBadge } from "../../components/ui";
import { useToast } from "../../hooks/useToast";
import { useAuth } from "../../context/AuthContext";
import { fetchSavedResume, saveResumeData } from "../../lib/api";

const steps = [
  { key: "personal", label: "Personal Info", icon: User },
  { key: "objective", label: "Career Objective", icon: Target },
  { key: "education", label: "Education", icon: GraduationCap },
  { key: "skills", label: "Skills", icon: Wrench },
  { key: "projects", label: "Projects", icon: FolderKanban },
  { key: "extras", label: "Certifications & More", icon: Award },
  { key: "preview", label: "Preview & Export", icon: FileText },
];

const templates = ["Modern", "Professional", "Minimal", "Software Engineer", "Data Analyst", "Business Analyst", "Fresher"];

const suggestedSkills = {
  technical: ["Python", "SQL", "React", "Java", "Git", "Machine Learning", "Data Structures", "REST APIs"],
  soft: ["Communication", "Teamwork", "Problem Solving", "Time Management", "Leadership", "Adaptability"],
};

interface Resume {
  name: string; email: string; phone: string; location: string; linkedin: string; github: string;
  objective: string;
  education: { degree: string; institution: string; year: string; score: string }[];
  skills: string[];
  projects: { title: string; desc: string }[];
  certifications: string; achievements: string; languages: string; hobbies: string; internships: string;
  template: string;
}

/* Everything starts EMPTY — only details we actually know (from the student's
   registration record) are prefilled. Placeholders guide the rest. */
const emptyResume: Resume = {
  name: "", email: "", phone: "", location: "", linkedin: "", github: "",
  objective: "",
  education: [{ degree: "", institution: "", year: "", score: "" }],
  skills: [],
  projects: [{ title: "", desc: "" }],
  certifications: "", achievements: "", languages: "", hobbies: "", internships: "",
  template: "Modern",
};

const personalFields: { key: keyof Resume; label: string; placeholder: string }[] = [
  { key: "name", label: "Full Name", placeholder: "Your full name" },
  { key: "email", label: "Email", placeholder: "you@college.edu" },
  { key: "phone", label: "Phone", placeholder: "e.g. +91 98XXXXXXXX" },
  { key: "location", label: "Location", placeholder: "City, Country" },
  { key: "linkedin", label: "LinkedIn", placeholder: "linkedin.com/in/your-profile" },
  { key: "github", label: "GitHub", placeholder: "github.com/your-username" },
];

const educationPlaceholders = {
  degree: "e.g. B.Tech Computer Science",
  institution: "Your college / university name",
  year: "e.g. 2023 – 2027",
  score: "e.g. CGPA 8.2",
};

const extraFields: { key: keyof Resume; label: string; placeholder: string }[] = [
  { key: "certifications", label: "Certifications", placeholder: "e.g. Python for Everybody — Coursera" },
  { key: "internships", label: "Internships", placeholder: "e.g. Web Development Intern, Company (Summer 2026)" },
  { key: "achievements", label: "Achievements", placeholder: "e.g. Hackathon winner, paper published, club lead" },
  { key: "languages", label: "Languages", placeholder: "e.g. English, Hindi, Tamil" },
  { key: "hobbies", label: "Hobbies (optional)", placeholder: "e.g. Chess, blogging, photography" },
];

function computeATS(r: Resume): { score: number; checks: { label: string; ok: boolean }[] } {
  const checks = [
    { label: "Contact details complete", ok: !!(r.name && r.email && r.phone) },
    { label: "Career objective present (40+ chars)", ok: r.objective.length >= 40 },
    { label: "At least 5 skills listed", ok: r.skills.length >= 5 },
    { label: "At least 2 projects with descriptions", ok: r.projects.filter((p) => p.title && p.desc.length > 30).length >= 2 },
    { label: "Education section complete", ok: r.education.every((e) => e.degree && e.institution) && r.education.length > 0 },
    { label: "Certifications included", ok: r.certifications.length > 5 },
    { label: "LinkedIn / GitHub links added", ok: !!(r.linkedin && r.github) },
    { label: "Quantified achievements (numbers/%)", ok: /\d/.test(r.projects.map((p) => p.desc).join(" ")) },
  ];
  const score = Math.round((checks.filter((c) => c.ok).length / checks.length) * 100);
  return { score, checks };
}

/* ---------- PDF export (jsPDF — a real, properly formatted PDF) ---------- */
function downloadResumePdf(r: Resume) {
  const doc = new jsPDF({ unit: "pt", format: "a4" });
  const W = doc.internal.pageSize.getWidth();
  const H = doc.internal.pageSize.getHeight();
  const M = 48;
  const width = W - M * 2;
  let y = 56;

  const violet: [number, number, number] = [109, 40, 217];
  const slate: [number, number, number] = [51, 65, 85];
  const gray: [number, number, number] = [100, 116, 139];

  const ensureSpace = (needed: number) => {
    if (y + needed > H - 48) {
      doc.addPage();
      y = 56;
    }
  };

  const text = (str: string, size: number, opts: { bold?: boolean; color?: [number, number, number]; gap?: number } = {}) => {
    if (!str) return;
    doc.setFont("helvetica", opts.bold ? "bold" : "normal");
    doc.setFontSize(size);
    doc.setTextColor(...(opts.color ?? slate));
    const lines = doc.splitTextToSize(str, width);
    for (const line of lines) {
      ensureSpace(size + 6);
      doc.text(line, M, y);
      y += size + 4;
    }
    y += opts.gap ?? 2;
  };

  const section = (title: string) => {
    ensureSpace(30);
    y += 8;
    doc.setFont("helvetica", "bold");
    doc.setFontSize(11);
    doc.setTextColor(...violet);
    doc.text(title.toUpperCase(), M, y);
    y += 5;
    doc.setDrawColor(...violet);
    doc.setLineWidth(0.8);
    doc.line(M, y, W - M, y);
    y += 14;
  };

  // Header
  text(r.name || "Resume", 22, { bold: true, color: [15, 23, 42], gap: 2 });
  text([r.email, r.phone, r.location].filter(Boolean).join("  ·  "), 10, { color: gray, gap: 0 });
  text([r.linkedin, r.github].filter(Boolean).join("  ·  "), 10, { color: violet, gap: 4 });

  if (r.objective) {
    section("Career Objective");
    text(r.objective, 10.5);
  }
  const edu = r.education.filter((e) => e.degree || e.institution);
  if (edu.length) {
    section("Education");
    edu.forEach((e) => {
      text(e.degree || "—", 11, { bold: true, gap: 0 });
      text([e.institution, e.year, e.score].filter(Boolean).join("  ·  "), 10, { color: gray });
    });
  }
  if (r.skills.length) {
    section("Skills");
    text(r.skills.join("  ·  "), 10.5);
  }
  const projects = r.projects.filter((p) => p.title || p.desc);
  if (projects.length) {
    section("Projects");
    projects.forEach((p) => {
      text(p.title || "—", 11, { bold: true, gap: 0 });
      text(p.desc, 10.5, { gap: 6 });
    });
  }
  if (r.internships) {
    section("Internships");
    text(r.internships, 10.5);
  }
  if (r.certifications || r.achievements) {
    section("Certifications & Achievements");
    text(r.certifications, 10.5);
    text(r.achievements, 10.5);
  }
  if (r.languages || r.hobbies) {
    section("Additional");
    if (r.languages) text(`Languages: ${r.languages}`, 10);
    if (r.hobbies) text(`Hobbies: ${r.hobbies}`, 10);
  }

  const fileName = `${(r.name || "resume").trim().replace(/\s+/g, "_")}_Resume.pdf`;
  doc.save(fileName);
  return fileName;
}

/* Rephrase without inventing facts — nudges the user to add real numbers */
function improveProject(desc: string): string {
  if (!desc.trim())
    return "Describe what you built, the technologies used, and one measurable result — e.g. \"Built [what] using [tech], achieving [metric]\".";
  let improved = desc
    .replace(/^built/i, "Designed and built")
    .replace(/^made/i, "Engineered")
    .replace(/^created/i, "Developed");
  if (!/\d/.test(improved)) improved = improved.replace(/\.?\s*$/, "") + " — add a measurable result here (accuracy %, users, time saved).";
  return improved;
}

export default function ResumeBuilder() {
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const [resume, setResume] = useState<Resume>(emptyResume);
  const [loaded, setLoaded] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const [toastEl, toast] = useToast();
  const saveTimer = useRef<ReturnType<typeof setTimeout>>();
  const ats = useMemo(() => computeATS(resume), [resume]);

  /* Load saved resume from resumes.xlsx; otherwise prefill only what we know */
  useEffect(() => {
    if (!user?.email) return;
    fetchSavedResume<Resume>(user.email)
      .then((saved) => {
        if (saved) {
          setResume({ ...emptyResume, ...saved });
          toast("Loaded your saved resume — continue where you left off");
        } else {
          setResume({
            ...emptyResume,
            name: user.name ?? "",
            email: user.email ?? "",
            education: [{
              degree: user.department ? `B.Tech ${user.department}` : "",
              institution: "",
              year: "",
              score: user.cgpa ? `CGPA ${user.cgpa}` : "",
            }],
          });
        }
      })
      .catch(() => {
        setResume({ ...emptyResume, name: user.name ?? "", email: user.email ?? "" });
      })
      .finally(() => setLoaded(true));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.email]);

  /* Debounced auto-save to resumes.xlsx on every change */
  useEffect(() => {
    if (!loaded || !user?.email) return;
    setSaveState("saving");
    if (saveTimer.current) clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(() => {
      saveResumeData(user.email!, resume)
        .then((r) => setSaveState(r.ok ? "saved" : "error"))
        .catch(() => setSaveState("error"));
    }, 1000);
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resume, loaded]);

  const set = <K extends keyof Resume>(k: K, v: Resume[K]) => setResume((r) => ({ ...r, [k]: v }));

  const generateObjective = () => {
    const dept = user?.department ? `${user.department} undergraduate` : "undergraduate student";
    const cg = user?.cgpa ? ` (CGPA ${user.cgpa})` : "";
    const skills = resume.skills.length ? ` with skills in ${resume.skills.slice(0, 3).join(", ")}` : "";
    const proj = resume.projects.find((p) => p.title.trim());
    const projPart = proj ? ` Built "${proj.title}" as a key project.` : "";
    set("objective", `Motivated ${dept}${cg}${skills}, seeking an opportunity to apply academic knowledge to real-world problems and deliver measurable impact.${projPart}`);
    toast("AI drafted an objective from your details — edit it to make it yours");
  };

  const atsColor = ats.score >= 80 ? "#22C55E" : ats.score >= 55 ? "#F59E0B" : "#EF4444";
  const saveLabel =
    saveState === "saving" ? "Saving…" : saveState === "saved" ? "Saved" : saveState === "error" ? "Save failed — is the server running?" : "";

  return (
    <div>
      {toastEl}
      <PageHeader
        title="AI Resume Builder"
        subtitle="Fill each step — your progress is saved automatically so you can continue anytime."
        icon={FileText}
        actions={
          <div className="flex items-center gap-3">
            {saveLabel && (
              <span className={`flex items-center gap-1.5 text-xs ${saveState === "error" ? "text-danger" : "text-muted"}`}>
                <CloudUpload size={13} className={saveState === "saving" ? "animate-pulseSoft" : ""} /> {saveLabel}
              </span>
            )}
            <AIBadge text={`ATS Score: ${ats.score}%`} />
          </div>
        }
      />

      {/* Stepper */}
      <div className="mb-6 flex flex-wrap gap-2">
        {steps.map((s, i) => (
          <button
            key={s.key}
            onClick={() => setStep(i)}
            className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs font-semibold transition-all ${
              i === step
                ? "bg-gradient-to-r from-primary to-secondary text-white shadow-glow"
                : i < step
                ? "bg-success/15 text-success"
                : "bg-white/5 text-muted hover:text-white"
            }`}
          >
            {i < step ? <CheckCircle2 size={14} /> : <s.icon size={14} />}
            <span className="hidden sm:inline">{s.label}</span>
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            <motion.div
              key={step}
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -24 }}
              transition={{ duration: 0.25 }}
            >
              <Card hover={false}>
                {step === 0 && (
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div className="col-span-full mb-1">
                      <h3 className="text-lg font-bold text-white">Personal Information</h3>
                      <p className="text-xs text-muted">Your name and email come from your account — everything else is yours to fill.</p>
                    </div>
                    {personalFields.map((f) => (
                      <div key={f.key}>
                        <label className="label">{f.label}</label>
                        <input
                          className="input"
                          placeholder={f.placeholder}
                          value={resume[f.key] as string}
                          onChange={(e) => set(f.key, e.target.value as never)}
                        />
                      </div>
                    ))}
                  </div>
                )}

                {step === 1 && (
                  <div>
                    <div className="mb-3 flex items-center justify-between">
                      <h3 className="text-lg font-bold text-white">Career Objective</h3>
                      <button className="btn-secondary !px-3 !py-1.5 text-xs" onClick={generateObjective}>
                        <Wand2 size={14} /> Generate with AI
                      </button>
                    </div>
                    <textarea
                      className="input min-h-[140px]"
                      placeholder="A concise 2–3 sentence summary of who you are and what you're aiming for. Tip: mention your degree, strongest skills, and the kind of role you want."
                      value={resume.objective}
                      onChange={(e) => set("objective", e.target.value)}
                    />
                    <p className="mt-2 text-xs text-muted">{resume.objective.length} characters · 40+ recommended for ATS.</p>
                  </div>
                )}

                {step === 2 && (
                  <div>
                    <h3 className="mb-1 text-lg font-bold text-white">Education</h3>
                    <p className="mb-3 text-xs text-muted">Your degree and CGPA are prefilled from your registration — complete the rest.</p>
                    {resume.education.map((ed, i) => (
                      <div key={i} className="mb-3 grid gap-3 rounded-xl border border-soft bg-white/5 p-4 sm:grid-cols-2">
                        {(["degree", "institution", "year", "score"] as const).map((f) => (
                          <div key={f}>
                            <label className="label capitalize">{f}</label>
                            <input
                              className="input"
                              placeholder={educationPlaceholders[f]}
                              value={ed[f]}
                              onChange={(e) => {
                                const next = [...resume.education];
                                next[i] = { ...next[i], [f]: e.target.value };
                                set("education", next);
                              }}
                            />
                          </div>
                        ))}
                        {resume.education.length > 1 && (
                          <button
                            className="text-left text-xs text-danger hover:underline"
                            onClick={() => set("education", resume.education.filter((_, x) => x !== i))}
                          >
                            Remove this entry
                          </button>
                        )}
                      </div>
                    ))}
                    <button
                      className="btn-ghost text-sm"
                      onClick={() => set("education", [...resume.education, { degree: "", institution: "", year: "", score: "" }])}
                    >
                      + Add Education
                    </button>
                  </div>
                )}

                {step === 3 && (
                  <div>
                    <h3 className="mb-3 text-lg font-bold text-white">Skills</h3>
                    <div className="mb-4 flex flex-wrap gap-2">
                      {resume.skills.map((s) => (
                        <button
                          key={s}
                          onClick={() => set("skills", resume.skills.filter((x) => x !== s))}
                          className="badge bg-primary/20 text-link hover:bg-danger/20 hover:text-danger"
                          title="Remove"
                        >
                          {s} ✕
                        </button>
                      ))}
                      {resume.skills.length === 0 && <p className="text-sm text-muted">No skills added yet — pick from the suggestions below or type your own.</p>}
                    </div>
                    <div className="mb-4 flex gap-2">
                      <input
                        className="input"
                        placeholder="Type a skill and press Enter (e.g. Python)"
                        onKeyDown={(e) => {
                          const v = (e.target as HTMLInputElement).value.trim();
                          if (e.key === "Enter" && v && !resume.skills.includes(v)) {
                            set("skills", [...resume.skills, v]);
                            (e.target as HTMLInputElement).value = "";
                          }
                        }}
                      />
                    </div>
                    <p className="label">Suggested technical skills</p>
                    <div className="mb-3 flex flex-wrap gap-2">
                      {suggestedSkills.technical.filter((s) => !resume.skills.includes(s)).map((s) => (
                        <button key={s} onClick={() => set("skills", [...resume.skills, s])} className="badge bg-white/5 text-body hover:bg-primary/20 hover:text-link">
                          + {s}
                        </button>
                      ))}
                    </div>
                    <p className="label">Suggested soft skills</p>
                    <div className="flex flex-wrap gap-2">
                      {suggestedSkills.soft.filter((s) => !resume.skills.includes(s)).map((s) => (
                        <button key={s} onClick={() => set("skills", [...resume.skills, s])} className="badge bg-white/5 text-body hover:bg-accent/20 hover:text-accent">
                          + {s}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {step === 4 && (
                  <div>
                    <h3 className="mb-3 text-lg font-bold text-white">Projects</h3>
                    {resume.projects.map((p, i) => (
                      <div key={i} className="mb-3 rounded-xl border border-soft bg-white/5 p-4">
                        <label className="label">Project Title</label>
                        <input
                          className="input mb-3"
                          placeholder="e.g. Student Attendance Tracker"
                          value={p.title}
                          onChange={(e) => {
                            const next = [...resume.projects];
                            next[i] = { ...next[i], title: e.target.value };
                            set("projects", next);
                          }}
                        />
                        <div className="mb-1.5 flex items-center justify-between">
                          <label className="label !mb-0">Description</label>
                          <button
                            className="link text-xs font-semibold"
                            onClick={() => {
                              const next = [...resume.projects];
                              next[i] = { ...next[i], desc: improveProject(p.desc) };
                              set("projects", next);
                              toast(p.desc.trim() ? "AI rephrased your description — add real numbers where marked" : "AI added a structure to follow");
                            }}
                          >
                            <Sparkles size={12} className="inline" /> Improve with AI
                          </button>
                        </div>
                        <textarea
                          className="input min-h-[80px]"
                          placeholder="What you built, the tech you used, and one measurable result (e.g. accuracy, users, time saved)"
                          value={p.desc}
                          onChange={(e) => {
                            const next = [...resume.projects];
                            next[i] = { ...next[i], desc: e.target.value };
                            set("projects", next);
                          }}
                        />
                        {resume.projects.length > 1 && (
                          <button className="mt-2 text-xs text-danger hover:underline" onClick={() => set("projects", resume.projects.filter((_, x) => x !== i))}>
                            Remove this project
                          </button>
                        )}
                      </div>
                    ))}
                    <button className="btn-ghost text-sm" onClick={() => set("projects", [...resume.projects, { title: "", desc: "" }])}>
                      + Add Project
                    </button>
                  </div>
                )}

                {step === 5 && (
                  <div className="grid gap-4">
                    <h3 className="text-lg font-bold text-white">Certifications & Additional Sections</h3>
                    {extraFields.map((f) => (
                      <div key={f.key}>
                        <label className="label">{f.label}</label>
                        <input
                          className="input"
                          placeholder={f.placeholder}
                          value={resume[f.key] as string}
                          onChange={(e) => set(f.key, e.target.value as never)}
                        />
                      </div>
                    ))}
                  </div>
                )}

                {step === 6 && (
                  <div>
                    <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                      <h3 className="text-lg font-bold text-white">Preview — {resume.template} Template</h3>
                      <div className="flex gap-2">
                        <button
                          className="btn-primary !px-3.5 !py-2 text-xs"
                          onClick={() => {
                            try {
                              const f = downloadResumePdf(resume);
                              toast(`Downloaded ${f}`);
                            } catch {
                              toast("PDF generation failed — please try again");
                            }
                          }}
                        >
                          <Download size={14} /> Download PDF
                        </button>
                        <button className="btn-ghost !px-3.5 !py-2 text-xs" onClick={() => window.print()}>
                          <Printer size={14} /> Print
                        </button>
                      </div>
                    </div>
                    <div className="mb-4 flex flex-wrap gap-2">
                      {templates.map((t) => (
                        <button
                          key={t}
                          onClick={() => set("template", t)}
                          className={`badge ${resume.template === t ? "bg-primary/25 text-link border border-primary/40" : "bg-white/5 text-muted hover:text-white"}`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>
                    {/* Resume preview — light background like a printed document */}
                    <div className="rounded-xl bg-white p-8 text-slate-800 shadow-card">
                      <h2 className="text-2xl font-bold text-slate-900">{resume.name || "Your Name"}</h2>
                      <p className="text-sm text-slate-500">
                        {[resume.email, resume.phone, resume.location].filter(Boolean).join(" · ") || "email · phone · location"}
                      </p>
                      {(resume.linkedin || resume.github) && (
                        <p className="text-sm text-violet-700">{[resume.linkedin, resume.github].filter(Boolean).join(" · ")}</p>
                      )}
                      {resume.objective && (
                        <>
                          <h4 className="mt-4 border-b border-slate-200 pb-1 text-sm font-bold uppercase tracking-wide text-violet-700">Career Objective</h4>
                          <p className="mt-1.5 text-sm">{resume.objective}</p>
                        </>
                      )}
                      {resume.education.some((e) => e.degree || e.institution) && (
                        <>
                          <h4 className="mt-4 border-b border-slate-200 pb-1 text-sm font-bold uppercase tracking-wide text-violet-700">Education</h4>
                          {resume.education.filter((e) => e.degree || e.institution).map((e, i) => (
                            <p key={i} className="mt-1.5 text-sm">
                              <span className="font-semibold">{e.degree}</span>
                              {e.institution && <> — {e.institution}</>}
                              {e.year && <> ({e.year})</>}
                              {e.score && <> · {e.score}</>}
                            </p>
                          ))}
                        </>
                      )}
                      {resume.skills.length > 0 && (
                        <>
                          <h4 className="mt-4 border-b border-slate-200 pb-1 text-sm font-bold uppercase tracking-wide text-violet-700">Skills</h4>
                          <p className="mt-1.5 text-sm">{resume.skills.join(" · ")}</p>
                        </>
                      )}
                      {resume.projects.some((p) => p.title || p.desc) && (
                        <>
                          <h4 className="mt-4 border-b border-slate-200 pb-1 text-sm font-bold uppercase tracking-wide text-violet-700">Projects</h4>
                          {resume.projects.filter((p) => p.title || p.desc).map((p, i) => (
                            <div key={i} className="mt-1.5">
                              <p className="text-sm font-semibold">{p.title}</p>
                              <p className="text-sm">{p.desc}</p>
                            </div>
                          ))}
                        </>
                      )}
                      {resume.internships && (
                        <>
                          <h4 className="mt-4 border-b border-slate-200 pb-1 text-sm font-bold uppercase tracking-wide text-violet-700">Internships</h4>
                          <p className="mt-1.5 text-sm">{resume.internships}</p>
                        </>
                      )}
                      {(resume.certifications || resume.achievements) && (
                        <>
                          <h4 className="mt-4 border-b border-slate-200 pb-1 text-sm font-bold uppercase tracking-wide text-violet-700">Certifications & Achievements</h4>
                          {resume.certifications && <p className="mt-1.5 text-sm">{resume.certifications}</p>}
                          {resume.achievements && <p className="mt-1 text-sm">{resume.achievements}</p>}
                        </>
                      )}
                      {(resume.languages || resume.hobbies) && (
                        <p className="mt-3 text-xs text-slate-500">
                          {resume.languages && <>Languages: {resume.languages}</>}
                          {resume.languages && resume.hobbies && " · "}
                          {resume.hobbies && <>Hobbies: {resume.hobbies}</>}
                        </p>
                      )}
                    </div>
                  </div>
                )}

                {/* Nav buttons */}
                <div className="mt-6 flex justify-between">
                  <button className="btn-ghost text-sm" disabled={step === 0} onClick={() => setStep(step - 1)}>
                    <ChevronLeft size={16} /> Back
                  </button>
                  {step < steps.length - 1 && (
                    <button className="btn-primary text-sm" onClick={() => setStep(step + 1)}>
                      Next <ChevronRight size={16} />
                    </button>
                  )}
                </div>
              </Card>
            </motion.div>
          </AnimatePresence>
        </div>

        {/* ATS panel */}
        <div className="space-y-6">
          <Card hover={false}>
            <div className="mb-3 flex items-center gap-2">
              <Sparkles size={17} className="text-link" />
              <h3 className="font-semibold text-white">ATS Compatibility</h3>
            </div>
            <div className="mb-2 flex items-end justify-between">
              <span className="text-4xl font-bold" style={{ color: atsColor }}>{ats.score}%</span>
              <Badge color={atsColor}>{ats.score >= 80 ? "Excellent" : ats.score >= 55 ? "Good" : "Needs Work"}</Badge>
            </div>
            <ProgressBar value={ats.score} color={atsColor} />
            <div className="mt-4 space-y-2">
              {ats.checks.map((c) => (
                <div key={c.label} className="flex items-center gap-2 text-xs">
                  <CheckCircle2 size={14} className={c.ok ? "text-success" : "text-muted opacity-40"} />
                  <span className={c.ok ? "text-body" : "text-muted"}>{c.label}</span>
                </div>
              ))}
            </div>
          </Card>
          <Card hover={false}>
            <h3 className="mb-2 font-semibold text-white">AI Tips</h3>
            <ul className="space-y-2 text-xs text-body">
              {!ats.checks[1].ok && <li>• Use "Generate with AI" to draft a career objective from your details.</li>}
              {!ats.checks[2].ok && <li>• Add at least 5 skills — mix technical and soft skills.</li>}
              {!ats.checks[3].ok && <li>• Add two projects with detailed, quantified descriptions.</li>}
              {!ats.checks[6].ok && <li>• Add your LinkedIn and GitHub links — recruiters check them.</li>}
              <li>• Use action verbs: designed, engineered, optimized, delivered.</li>
              <li>• Quantify results — "improved accuracy by 12%" beats "improved accuracy".</li>
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}
