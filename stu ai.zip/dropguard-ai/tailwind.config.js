/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#7C3AED",
        secondary: "#A855F7",
        accent: "#06B6D4",
        success: "#22C55E",
        warning: "#F59E0B",
        danger: "#EF4444",
        bg: "#0F172A",
        card: "#1E293B",
        navbar: "#111827",
        sidebar: "#1E1B4B",
        heading: "#FFFFFF",
        body: "#CBD5E1",
        muted: "#94A3B8",
        link: "#A78BFA",
      },
      borderColor: {
        soft: "rgba(255,255,255,0.08)",
      },
      fontFamily: {
        sans: ["Poppins", "Inter", "system-ui", "sans-serif"],
      },
      borderRadius: {
        card: "20px",
      },
      boxShadow: {
        card: "0 15px 35px rgba(0,0,0,.25)",
        glow: "0 0 25px rgba(124,58,237,.45)",
        glowCyan: "0 0 25px rgba(6,182,212,.4)",
      },
      keyframes: {
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-12px)" },
        },
        pulseSoft: {
          "0%,100%": { opacity: "1" },
          "50%": { opacity: ".55" },
        },
      },
      animation: {
        float: "float 5s ease-in-out infinite",
        pulseSoft: "pulseSoft 2.4s ease-in-out infinite",
      },
    },
  },
  plugins: [],
};
